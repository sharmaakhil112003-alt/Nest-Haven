package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import com.example.data.firebase.AuthManager
import com.example.data.location.IndiaLocations
import com.example.security.SecurityCrypto
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppLocalization
import com.example.ui.i18n.formatInr
import com.example.ui.screens.NestHavenHomeScreen
import com.example.ui.screens.NestHavenLoginRegisterScreen
import com.example.ui.theme.NestHavenTheme
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuthException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `app name and firebase project id match Nest Haven configuration`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        val projectId = context.getString(R.string.project_id)
        assertEquals("Nest Haven", appName)
        assertEquals("gen-lang-client-0181466425", projectId)
    }

    @Test
    fun `email validation and Firebase Email Auth error mapping work cleanly`() {
        assertTrue(AuthManager.isValidEmail("tenant@nesthaven.in"))
        assertFalse(AuthManager.isValidEmail("invalid-email"))
        assertFalse(AuthManager.isValidEmail(""))

        val disabledErr = FirebaseAuthException("ERROR_OPERATION_NOT_ALLOWED", "Password sign-in is disabled.")
        assertTrue(AuthManager.mapFirebaseEmailAuthException(disabledErr).contains("Email/Password"))

        val collisionErr = FirebaseAuthException("ERROR_EMAIL_ALREADY_IN_USE", "Email already exists.")
        assertTrue(AuthManager.mapFirebaseEmailAuthException(collisionErr).contains("already exists"))

        val notFoundErr = FirebaseAuthException("ERROR_USER_NOT_FOUND", "No user record.")
        assertTrue(AuthManager.mapFirebaseEmailAuthException(notFoundErr).contains("No Nest Haven account"))

        val badCredErr = FirebaseAuthException("ERROR_INVALID_CREDENTIAL", "Invalid credentials.")
        assertTrue(AuthManager.mapFirebaseEmailAuthException(badCredErr).contains("Incorrect email or password"))

        val rateErr = FirebaseTooManyRequestsException("Too many attempts.")
        assertTrue(AuthManager.mapFirebaseEmailAuthException(rateErr).contains("Too many authentication attempts"))
    }

    @Test
    fun `india location catalog includes Himachal Pradesh Shimla Indira Nagar`() {
        val hp = IndiaLocations.allStatesAndUTs.firstOrNull { it.name == "Himachal Pradesh" }
        assertTrue(hp != null)
        val shimla = hp?.cities?.firstOrNull { it.name == "Shimla" }
        assertTrue(shimla != null)
        val indiraNagar = shimla?.localities?.firstOrNull { it.name == "Indira Nagar" }
        assertTrue(indiraNagar != null)
        assertTrue(IndiaLocations.allStatesAndUTs.size >= 36)
    }

    @Test
    fun `localization supports English, Hindi and INR formatting`() {
        val en = AppLocalization.get(AppLanguage.ENGLISH)
        val hi = AppLocalization.get(AppLanguage.HINDI)
        assertEquals("Find Your Space. Feel at Home.", en.tagline)
        assertEquals("Welcome to Nest Haven", en.welcomeToNestHaven)
        assertEquals("Find Your Perfect Stay", en.findYourPerfectStay)
        assertEquals("TENANT - Find Rooms", en.tenantCtaTitle)
        assertEquals("PROPERTY OWNER - Owner Login", en.ownerCtaTitle)
        assertTrue(hi.ownerCtaTitle.contains("PROPERTY OWNER"))
        assertEquals("₹6,000", formatInr(6000L))
    }

    @Test
    fun `security crypto validates strong passwords and totp`() {
        assertFalse(SecurityCrypto.validatePasswordStrength("weak123").isStrong)
        assertTrue(SecurityCrypto.validatePasswordStrength("NestHaven@2026!").isStrong)
        val secret = SecurityCrypto.generateBase32Secret(16)
        val code = SecurityCrypto.computeTotpCode(secret)
        assertTrue(SecurityCrypto.verifyTotpCode(secret, code))
    }

    @Test
    fun `login register screen uses only Email and Password auth with Forgot Password and zero Phone OTP`() {
        composeRule.setContent {
            NestHavenTheme {
                NestHavenLoginRegisterScreen(
                    language = AppLanguage.ENGLISH,
                    activeSessionLabel = null,
                    isSessionEmailVerified = false,
                    onLanguageChange = {},
                    onContinueActiveSession = {},
                    onAuthSucceededToHomepage = { _, _ -> }
                )
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithText("Welcome to Nest Haven").assertIsDisplayed()
        composeRule.onNodeWithText("Find Your Perfect Stay").assertIsDisplayed()
        composeRule.onNodeWithTag("email_login_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("password_login_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("forgot_password_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("email_login_button").performScrollTo().assertIsDisplayed().assertIsEnabled()

        // Ensure Mobile OTP / Phone Auth UI is completely absent
        composeRule.onNodeWithTag("mobile_login_input").assertDoesNotExist()
        composeRule.onNodeWithTag("mobile_login_send_otp_button").assertDoesNotExist()
        composeRule.onNodeWithTag("test_number_mode_toggle").assertDoesNotExist()
        composeRule.onNodeWithTag("auth_diagnostics_toggle_button").assertDoesNotExist()

        // Open Forgot Password & Reset Password view
        composeRule.onNodeWithTag("forgot_password_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("reset_password_email_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("send_reset_password_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("back_from_reset_button").performScrollTo().performClick()
        composeRule.waitForIdle()

        // Switch to separate REGISTER tab & verify Email + Password + Confirm Password fields
        composeRule.onNodeWithTag("open_register_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("reg_fullname_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("reg_email_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("reg_password_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("reg_confirm_password_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("create_account_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("reg_mobile_input").assertDoesNotExist()
        composeRule.onNodeWithTag("reg_send_mobile_otp_button").assertDoesNotExist()
    }

    @Test
    fun `unverified active session opens email verification panel instead of bypassing to homepage`() {
        var continued = false
        composeRule.setContent {
            NestHavenTheme {
                NestHavenLoginRegisterScreen(
                    language = AppLanguage.ENGLISH,
                    activeSessionLabel = "user@nesthaven.in",
                    isSessionEmailVerified = false,
                    onLanguageChange = {},
                    onContinueActiveSession = { continued = true },
                    onAuthSucceededToHomepage = { _, _ -> }
                )
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("continue_active_session_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertFalse(continued)
        composeRule.onNodeWithTag("email_verification_panel").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("check_email_verified_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("resend_verification_email_button").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun `homepage routes Tenant Find Rooms and Property Owner Login buttons`() {
        var tenantClicked = false
        var ownerClicked = false
        composeRule.setContent {
            NestHavenTheme {
                NestHavenHomeScreen(
                    selectedLanguage = AppLanguage.ENGLISH,
                    signedInEmail = "tenant@nesthaven.in",
                    previewState = "Himachal Pradesh",
                    previewCity = "Shimla",
                    previewLocality = "Indira Nagar",
                    previewRoomPreference = "ANY",
                    previewBudgetInr = 6000L,
                    onLanguageChange = {},
                    onPreviewFiltersChange = { _, _, _, _, _ -> },
                    onFindRoomsClick = { tenantClicked = true },
                    onOwnerLoginClick = { ownerClicked = true },
                    onSignOutClick = {}
                )
            }
        }
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("tenant_find_rooms_button").performScrollTo().performClick()
        composeRule.onNodeWithTag("property_owner_login_button").performScrollTo().performClick()
        assertTrue(tenantClicked)
        assertTrue(ownerClicked)
    }
}
