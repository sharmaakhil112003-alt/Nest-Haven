package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Brand Palette — Nest Haven Architectural Sanctuary & Zero-Trust Vault
val DeepEmerald = Color(0xFF0C3227)
val DeepEmeraldLight = Color(0xFF154D3D)
val ChampagneGold = Color(0xFFD4A23C)
val ChampagneGoldSoft = Color(0xFFF6E7C1)
val WarmIvory = Color(0xFFF7F4EC)
val SoftAlabaster = Color(0xFFFFFFFF)
val SageMist = Color(0xFFE6ECE8)
val SlateCharcoal = Color(0xFF1B2421)
val MutedPineText = Color(0xFF4D5E58)

// Dark Vault Surfaces
val ObsidianVault = Color(0xFF07130F)
val ObsidianCard = Color(0xFF0F201B)
val ObsidianElevated = Color(0xFF162C25)
val IvoryOnDark = Color(0xFFF2EFE7)
val MutedSageOnDark = Color(0xFFA6B8B0)

// Semantic Status Tokens
val VerifiedJade = Color(0xFF157F58)
val VerifiedJadeContainer = Color(0xFFD7F4E6)
val AmberWarning = Color(0xFFB56E08)
val AmberWarningContainer = Color(0xFFFFEBC8)
val CrimsonAlert = Color(0xFFBA1A1A)
val CrimsonAlertContainer = Color(0xFFFFDAD6)
