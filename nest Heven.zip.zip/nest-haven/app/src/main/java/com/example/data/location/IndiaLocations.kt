package com.example.data.location

data class LocalityCatalog(
    val name: String,
    val buildings: List<String> = emptyList()
)

data class CityCatalog(
    val name: String,
    val localities: List<LocalityCatalog>
)

data class StateCatalog(
    val name: String,
    val cities: List<CityCatalog>
)

object IndiaLocations {
    val allStatesAndUTs: List<StateCatalog> = listOf(
        StateCatalog(
            name = "Himachal Pradesh",
            cities = listOf(
                CityCatalog(
                    name = "Shimla",
                    localities = listOf(
                        LocalityCatalog("Indira Nagar", listOf("Deodar Heights", "Cedar Residency", "Sanjauli Crest")),
                        LocalityCatalog("Sanjauli", listOf("Himalayan View Residency", "Pine Crest")),
                        LocalityCatalog("New Shimla", listOf("Sector 1 Block", "Sector 2 Enclave")),
                        LocalityCatalog("Chotta Shimla"),
                        LocalityCatalog("Summer Hill"),
                        LocalityCatalog("Kasumpti")
                    )
                ),
                CityCatalog(
                    name = "Dharamshala",
                    localities = listOf(
                        LocalityCatalog("McLeod Ganj", listOf("Dhauladhar Sanctuary")),
                        LocalityCatalog("Dharamkot"),
                        LocalityCatalog("Sidhbari"),
                        LocalityCatalog("Kotwali Bazaar")
                    )
                ),
                CityCatalog(
                    name = "Manali",
                    localities = listOf(
                        LocalityCatalog("Old Manali"),
                        LocalityCatalog("Vashisht"),
                        LocalityCatalog("Aleo")
                    )
                ),
                CityCatalog(name = "Solan", localities = listOf(LocalityCatalog("Mall Road"), LocalityCatalog("Chambaghat"))),
                CityCatalog(name = "Mandi", localities = listOf(LocalityCatalog("Seri Bazaar"), LocalityCatalog("Jail Road")))
            )
        ),
        StateCatalog(
            name = "Uttarakhand",
            cities = listOf(
                CityCatalog("Dehradun", listOf(LocalityCatalog("Rajpur Road"), LocalityCatalog("Clement Town"), LocalityCatalog("Ballupur"))),
                CityCatalog("Rishikesh", listOf(LocalityCatalog("Tapovan"), LocalityCatalog("Lakshman Jhula"))),
                CityCatalog("Nainital", listOf(LocalityCatalog("Tallital"), LocalityCatalog("Mallital"))),
                CityCatalog("Haridwar", listOf(LocalityCatalog("Jwalapur"), LocalityCatalog("Ranipur More")))
            )
        ),
        StateCatalog(
            name = "Delhi (NCT)",
            cities = listOf(
                CityCatalog(
                    name = "New Delhi",
                    localities = listOf(
                        LocalityCatalog("Mukherjee Nagar"),
                        LocalityCatalog("Laxmi Nagar"),
                        LocalityCatalog("Karol Bagh"),
                        LocalityCatalog("Hauz Khas"),
                        LocalityCatalog("Dwarka Sector 12"),
                        LocalityCatalog("Saket")
                    )
                )
            )
        ),
        StateCatalog(
            name = "Maharashtra",
            cities = listOf(
                CityCatalog("Mumbai", listOf(LocalityCatalog("Andheri West"), LocalityCatalog("Powai"), LocalityCatalog("Bandra West"), LocalityCatalog("Dadar"))),
                CityCatalog("Pune", listOf(LocalityCatalog("Kothrud"), LocalityCatalog("Hinjewadi"), LocalityCatalog("Viman Nagar"), LocalityCatalog("Shivaji Nagar"))),
                CityCatalog("Nagpur", listOf(LocalityCatalog("Dharampeth"), LocalityCatalog("Sitabuldi")))
            )
        ),
        StateCatalog(
            name = "Karnataka",
            cities = listOf(
                CityCatalog("Bengaluru", listOf(LocalityCatalog("Koramangala"), LocalityCatalog("Indiranagar"), LocalityCatalog("HSR Layout"), LocalityCatalog("Whitefield"), LocalityCatalog("BTM Layout"))),
                CityCatalog("Mysuru", listOf(LocalityCatalog("Gokulam"), LocalityCatalog("Vijayanagar")))
            )
        ),
        StateCatalog(
            name = "Chandigarh",
            cities = listOf(
                CityCatalog("Chandigarh", listOf(LocalityCatalog("Sector 15"), LocalityCatalog("Sector 22"), LocalityCatalog("Sector 34"), LocalityCatalog("Manimajra")))
            )
        ),
        StateCatalog(
            name = "Punjab",
            cities = listOf(
                CityCatalog("Mohali", listOf(LocalityCatalog("Phase 7"), LocalityCatalog("Sector 70"))),
                CityCatalog("Ludhiana", listOf(LocalityCatalog("Sarabha Nagar"), LocalityCatalog("Model Town"))),
                CityCatalog("Amritsar", listOf(LocalityCatalog("Ranjit Avenue"), LocalityCatalog("Lawrence Road")))
            )
        ),
        StateCatalog(
            name = "Haryana",
            cities = listOf(
                CityCatalog("Gurugram", listOf(LocalityCatalog("DLF Phase 3"), LocalityCatalog("Sector 56"), LocalityCatalog("Sohna Road"))),
                CityCatalog("Faridabad", listOf(LocalityCatalog("Sector 15"), LocalityCatalog("NIT")))
            )
        ),
        StateCatalog(
            name = "Uttar Pradesh",
            cities = listOf(
                CityCatalog("Noida", listOf(LocalityCatalog("Sector 62"), LocalityCatalog("Sector 18"), LocalityCatalog("Sector 137"))),
                CityCatalog("Lucknow", listOf(LocalityCatalog("Gomti Nagar"), LocalityCatalog("Hazratganj"), LocalityCatalog("Aliganj"))),
                CityCatalog("Varanasi", listOf(LocalityCatalog("Lanka"), LocalityCatalog("Sigra"))),
                CityCatalog("Prayagraj", listOf(LocalityCatalog("Civil Lines"), LocalityCatalog("Katra")))
            )
        ),
        StateCatalog(
            name = "Rajasthan",
            cities = listOf(
                CityCatalog("Jaipur", listOf(LocalityCatalog("Malviya Nagar"), LocalityCatalog("Vaishali Nagar"), LocalityCatalog("Mansarovar"))),
                CityCatalog("Kota", listOf(LocalityCatalog("Vigyan Nagar"), LocalityCatalog("Talwandi"))),
                CityCatalog("Udaipur", listOf(LocalityCatalog("Fatehpura"), LocalityCatalog("Hiran Magri")))
            )
        ),
        StateCatalog(
            name = "Telangana",
            cities = listOf(
                CityCatalog("Hyderabad", listOf(LocalityCatalog("Madhapur"), LocalityCatalog("Gachibowli"), LocalityCatalog("Kukatpally"), LocalityCatalog("Ameerpet")))
            )
        ),
        StateCatalog(
            name = "Tamil Nadu",
            cities = listOf(
                CityCatalog("Chennai", listOf(LocalityCatalog("Adyar"), LocalityCatalog("Velachery"), LocalityCatalog("Anna Nagar"), LocalityCatalog("OMR Thoraipakkam"))),
                CityCatalog("Coimbatore", listOf(LocalityCatalog("RS Puram"), LocalityCatalog("Peelamedu")))
            )
        ),
        StateCatalog(
            name = "Gujarat",
            cities = listOf(
                CityCatalog("Ahmedabad", listOf(LocalityCatalog("Navrangpura"), LocalityCatalog("Satellite"), LocalityCatalog("SG Highway"))),
                CityCatalog("Surat", listOf(LocalityCatalog("Vesu"), LocalityCatalog("Adajan")))
            )
        ),
        StateCatalog(
            name = "West Bengal",
            cities = listOf(
                CityCatalog("Kolkata", listOf(LocalityCatalog("Salt Lake Sector V"), LocalityCatalog("New Town"), LocalityCatalog("Ballygunge")))
            )
        ),
        StateCatalog(
            name = "Madhya Pradesh",
            cities = listOf(
                CityCatalog("Indore", listOf(LocalityCatalog("Vijay Nagar"), LocalityCatalog("Palasia"))),
                CityCatalog("Bhopal", listOf(LocalityCatalog("MP Nagar"), LocalityCatalog("Arera Colony")))
            )
        ),
        StateCatalog(
            name = "Bihar",
            cities = listOf(CityCatalog("Patna", listOf(LocalityCatalog("Boring Road"), LocalityCatalog("Kankarbagh"))))
        ),
        StateCatalog(name = "Andhra Pradesh", cities = listOf(CityCatalog("Visakhapatnam", listOf(LocalityCatalog("MVP Colony"), LocalityCatalog("Madhurawada"))))),
        StateCatalog(name = "Arunachal Pradesh", cities = listOf(CityCatalog("Itanagar", listOf(LocalityCatalog("Naharlagun"), LocalityCatalog("Ganga Market"))))),
        StateCatalog(name = "Assam", cities = listOf(CityCatalog("Guwahati", listOf(LocalityCatalog("GS Road"), LocalityCatalog("Beltola"))))),
        StateCatalog(name = "Chhattisgarh", cities = listOf(CityCatalog("Raipur", listOf(LocalityCatalog("Shankar Nagar"), LocalityCatalog("Civil Lines"))))),
        StateCatalog(name = "Goa", cities = listOf(CityCatalog("Panaji", listOf(LocalityCatalog("Miramar"), LocalityCatalog("Porvorim"))))),
        StateCatalog(name = "Jharkhand", cities = listOf(CityCatalog("Ranchi", listOf(LocalityCatalog("Lalpur"), LocalityCatalog("Kanke Road"))))),
        StateCatalog(name = "Kerala", cities = listOf(CityCatalog("Kochi", listOf(LocalityCatalog("Kakkanad"), LocalityCatalog("Edappally"))))),
        StateCatalog(name = "Manipur", cities = listOf(CityCatalog("Imphal", listOf(LocalityCatalog("Thangal Bazar"))))),
        StateCatalog(name = "Meghalaya", cities = listOf(CityCatalog("Shillong", listOf(LocalityCatalog("Laitumkhrah"))))),
        StateCatalog(name = "Mizoram", cities = listOf(CityCatalog("Aizawl", listOf(LocalityCatalog("Dawrpui"))))),
        StateCatalog(name = "Nagaland", cities = listOf(CityCatalog("Kohima", listOf(LocalityCatalog("PR Hill"))))),
        StateCatalog(name = "Odisha", cities = listOf(CityCatalog("Bhubaneswar", listOf(LocalityCatalog("Patia"), LocalityCatalog("Saheed Nagar"))))),
        StateCatalog(name = "Sikkim", cities = listOf(CityCatalog("Gangtok", listOf(LocalityCatalog("MG Marg"), LocalityCatalog("Tadong"))))),
        StateCatalog(name = "Tripura", cities = listOf(CityCatalog("Agartala", listOf(LocalityCatalog("Krishnanagar"))))),
        StateCatalog(name = "Andaman and Nicobar Islands", cities = listOf(CityCatalog("Port Blair", listOf(LocalityCatalog("Aberdeen Bazaar"))))),
        StateCatalog(name = "Dadra and Nagar Haveli and Daman and Diu", cities = listOf(CityCatalog("Daman", listOf(LocalityCatalog("Nani Daman"))))),
        StateCatalog(name = "Jammu and Kashmir", cities = listOf(CityCatalog("Jammu", listOf(LocalityCatalog("Gandhi Nagar"))), CityCatalog("Srinagar", listOf(LocalityCatalog("Rajbagh"))))),
        StateCatalog(name = "Ladakh", cities = listOf(CityCatalog("Leh", listOf(LocalityCatalog("Changspa"))))),
        StateCatalog(name = "Lakshadweep", cities = listOf(CityCatalog("Kavaratti", listOf(LocalityCatalog("Central Jetty"))))),
        StateCatalog(name = "Puducherry", cities = listOf(CityCatalog("Puducherry", listOf(LocalityCatalog("White Town")))))
    )

    val standardFacilities: List<String> = listOf(
        "Wi-Fi", "Geyser", "Attached Bath", "Almirah", "Balcony",
        "Power Backup", "RO Water", "CCTV Security", "Parking", "Kitchen Access"
    )
}
