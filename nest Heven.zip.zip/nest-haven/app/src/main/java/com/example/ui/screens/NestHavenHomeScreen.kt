package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HomeWork
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.location.IndiaLocations
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppLocalization
import com.example.ui.i18n.formatInr
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneGoldSoft
import com.example.ui.theme.DeepEmerald
import com.example.ui.theme.DeepEmeraldLight
import com.example.ui.theme.IvoryOnDark
import com.example.ui.theme.MutedSageOnDark

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NestHavenHomeScreen(
    selectedLanguage: AppLanguage,
    signedInEmail: String?,
    previewState: String,
    previewCity: String,
    previewLocality: String,
    previewRoomPreference: String,
    previewBudgetInr: Long,
    onLanguageChange: (AppLanguage) -> Unit,
    onPreviewFiltersChange: (
        state: String,
        city: String,
        locality: String,
        roomPref: String,
        budgetInr: Long
    ) -> Unit,
    onFindRoomsClick: () -> Unit,
    onOwnerLoginClick: () -> Unit,
    onSignOutClick: () -> Unit = {}
) {
    val strings = AppLocalization.get(selectedLanguage)
    val statesList = IndiaLocations.allStatesAndUTs
    val selectedStateCatalog = remember(previewState) {
        statesList.firstOrNull { it.name == previewState } ?: statesList.first()
    }
    val selectedCityCatalog = remember(selectedStateCatalog, previewCity) {
        selectedStateCatalog.cities.firstOrNull { it.name == previewCity } ?: selectedStateCatalog.cities.first()
    }
    val selectedLocalityCatalog = remember(selectedCityCatalog, previewLocality) {
        selectedCityCatalog.localities.firstOrNull { it.name == previewLocality } ?: selectedCityCatalog.localities.first()
    }
    var showLocationPreview by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepEmerald)
    ) {
        // Unified traditional Himalayan house + peaceful meditating Sadhu artwork backdrop
        Image(
            painter = painterResource(id = R.drawable.img_himalayan_sadhu_bg),
            contentDescription = "Traditional Himalayan house with peaceful meditating Sadhu backdrop",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Balanced dark-emerald gradient scrim keeping the Himalayan house & Sadhu luminous in the center
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0.00f to Color(0xFF041711).copy(alpha = 0.86f),
                        0.26f to DeepEmerald.copy(alpha = 0.42f),
                        0.48f to Color.Transparent,
                        0.66f to DeepEmerald.copy(alpha = 0.56f),
                        0.82f to Color(0xFF061E16).copy(alpha = 0.92f),
                        1.00f to Color(0xFF04140F).copy(alpha = 0.98f)
                    )
                )
        )

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            val availableHeight = maxHeight

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .defaultMinSize(minHeight = availableHeight)
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Upper Header: Nest Haven Logo + Name + EN/हिंदी + Tagline
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 560.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_launcher_emblem),
                                contentDescription = "Nest Haven Logo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(2.dp, ChampagneGold, RoundedCornerShape(14.dp))
                            )
                            Column {
                                Text(
                                    text = strings.appName,
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        shadow = Shadow(
                                            color = Color.Black.copy(alpha = 0.55f),
                                            blurRadius = 6f
                                        )
                                    ),
                                    color = ChampagneGoldSoft
                                )
                                Text(
                                    text = "All-India Verified Stays • ₹ INR",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = IvoryOnDark.copy(alpha = 0.85f)
                                )
                            }
                        }

                        LanguageTogglePill(
                            selectedLanguage = selectedLanguage,
                            onLanguageChange = onLanguageChange
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    Text(
                        text = strings.tagline,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            shadow = Shadow(
                                color = Color.Black.copy(alpha = 0.65f),
                                blurRadius = 10f
                            )
                        ),
                        color = ChampagneGoldSoft,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = strings.heroSubtitle,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            shadow = Shadow(
                                color = Color.Black.copy(alpha = 0.65f),
                                blurRadius = 8f
                            )
                        ),
                        color = IvoryOnDark.copy(alpha = 0.94f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.widthIn(max = 460.dp)
                    )

                    if (!signedInEmail.isNullOrBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Surface(
                            color = DeepEmerald.copy(alpha = 0.88f),
                            shape = RoundedCornerShape(999.dp),
                            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .clickable { onSignOutClick() }
                                .testTag("homepage_switch_account_badge")
                        ) {
                            Text(
                                text = "Signed in: $signedInEmail • Switch / Sign Out",
                                style = MaterialTheme.typography.labelSmall,
                                color = ChampagneGoldSoft,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                // Scenic framing window preserving clear visibility of the Himalayan house & Sadhu
                Spacer(modifier = Modifier.defaultMinSize(minHeight = 190.dp))

                // Lower Action Dock: Prominent Tenant & Property Owner Buttons + Optional Quick Preview
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 560.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        HomeHighlightChip(Icons.Filled.LocationOn, "State • City • Locality")
                        HomeHighlightChip(Icons.Filled.Bed, "Single & Double")
                        HomeHighlightChip(Icons.Filled.CurrencyRupee, "₹99 Search Fee")
                    }

                    Spacer(Modifier.height(2.dp))

                    // Primary Action 1: TENANT - Find Rooms
                    Button(
                        onClick = onFindRoomsClick,
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ChampagneGold,
                            contentColor = DeepEmerald
                        ),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(62.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("tenant_find_rooms_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = strings.tenantCtaTitle,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = strings.tenantCtaTitle,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null
                        )
                    }

                    // Primary Action 2: PROPERTY OWNER - Owner Login
                    OutlinedButton(
                        onClick = onOwnerLoginClick,
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color(0xFF0A2D22).copy(alpha = 0.94f),
                            contentColor = ChampagneGoldSoft
                        ),
                        border = BorderStroke(1.8.dp, ChampagneGold),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(62.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("property_owner_login_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.HomeWork,
                            contentDescription = strings.ownerCtaTitle,
                            tint = ChampagneGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = strings.ownerCtaTitle,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = ChampagneGoldSoft,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = ChampagneGold
                        )
                    }

                    TextButton(
                        onClick = { showLocationPreview = !showLocationPreview },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("toggle_location_preview_button")
                    ) {
                        Icon(
                            imageVector = if (showLocationPreview) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                            contentDescription = null,
                            tint = ChampagneGold
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = if (showLocationPreview) {
                                "Hide Location Search Preview"
                            } else {
                                "Preview State / City / Locality (${selectedCityCatalog.name})"
                            },
                            color = ChampagneGoldSoft,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }

                    AnimatedVisibility(
                        visible = showLocationPreview,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF09271E).copy(alpha = 0.96f)),
                            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.5f))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = strings.homepageHighlightsTitle,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = ChampagneGoldSoft
                                )

                                HomeLocationDropdown(
                                    label = strings.selectState,
                                    selected = selectedStateCatalog.name,
                                    options = statesList.map { it.name },
                                    onSelect = { stName ->
                                        val st = statesList.first { it.name == stName }
                                        val c = st.cities.first()
                                        val l = c.localities.first()
                                        onPreviewFiltersChange(st.name, c.name, l.name, previewRoomPreference, previewBudgetInr)
                                    }
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(modifier = Modifier.weight(1f)) {
                                        HomeLocationDropdown(
                                            label = strings.selectCity,
                                            selected = selectedCityCatalog.name,
                                            options = selectedStateCatalog.cities.map { it.name },
                                            onSelect = { cName ->
                                                val c = selectedStateCatalog.cities.first { it.name == cName }
                                                val l = c.localities.first()
                                                onPreviewFiltersChange(
                                                    selectedStateCatalog.name,
                                                    c.name,
                                                    l.name,
                                                    previewRoomPreference,
                                                    previewBudgetInr
                                                )
                                            }
                                        )
                                    }
                                    Box(modifier = Modifier.weight(1f)) {
                                        HomeLocationDropdown(
                                            label = strings.selectLocality,
                                            selected = selectedLocalityCatalog.name,
                                            options = selectedCityCatalog.localities.map { it.name },
                                            onSelect = { lName ->
                                                onPreviewFiltersChange(
                                                    selectedStateCatalog.name,
                                                    selectedCityCatalog.name,
                                                    lName,
                                                    previewRoomPreference,
                                                    previewBudgetInr
                                                )
                                            }
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf("ANY" to "Any", "SINGLE" to "Single", "DOUBLE" to "Double").forEach { (code, lbl) ->
                                            FilterChip(
                                                selected = previewRoomPreference == code,
                                                onClick = {
                                                    onPreviewFiltersChange(
                                                        selectedStateCatalog.name,
                                                        selectedCityCatalog.name,
                                                        selectedLocalityCatalog.name,
                                                        code,
                                                        previewBudgetInr
                                                    )
                                                },
                                                label = { Text(lbl) }
                                            )
                                        }
                                    }
                                    Surface(
                                        color = ChampagneGoldSoft,
                                        shape = RoundedCornerShape(999.dp),
                                        modifier = Modifier.clickable {
                                            val nextBudget = when (previewBudgetInr) {
                                                6000L -> 10000L
                                                10000L -> 15000L
                                                else -> 6000L
                                            }
                                            onPreviewFiltersChange(
                                                selectedStateCatalog.name,
                                                selectedCityCatalog.name,
                                                selectedLocalityCatalog.name,
                                                previewRoomPreference,
                                                nextBudget
                                            )
                                        }
                                    ) {
                                        Text(
                                            text = "Budget ${formatInr(previewBudgetInr)}/mo",
                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                            color = DeepEmerald,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        )
                                    }
                                }

                                Button(
                                    onClick = onFindRoomsClick,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = DeepEmeraldLight,
                                        contentColor = ChampagneGoldSoft
                                    ),
                                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.65f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("homepage_explore_locality_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Apartment,
                                        contentDescription = null,
                                        tint = ChampagneGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = "Explore ${selectedLocalityCatalog.name}, ${selectedCityCatalog.name} (₹99 Unlock)",
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }

                    Text(
                        text = strings.selectRoleNotice,
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedSageOnDark,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeLocationDropdown(
    label: String,
    selected: String,
    options: List<String>,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = Modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label, color = MutedSageOnDark) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = ChampagneGoldSoft,
                unfocusedTextColor = IvoryOnDark,
                focusedBorderColor = ChampagneGold,
                unfocusedBorderColor = ChampagneGold.copy(alpha = 0.45f),
                focusedTrailingIconColor = ChampagneGold,
                unfocusedTrailingIconColor = ChampagneGoldSoft
            ),
            singleLine = true,
            modifier = Modifier
                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                .fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onSelect(option)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun HomeHighlightChip(icon: ImageVector, label: String) {
    Surface(
        color = DeepEmerald.copy(alpha = 0.85f),
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.48f))
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
            Icon(icon, contentDescription = null, tint = ChampagneGold, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(5.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGoldSoft
            )
        }
    }
}
