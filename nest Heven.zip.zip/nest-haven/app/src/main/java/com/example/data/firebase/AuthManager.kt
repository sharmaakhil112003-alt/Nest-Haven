package com.example.data.firebase

import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Firebase Email & Password Authentication manager for Nest Haven.
 * Supports sign-in, registration with email verification, password reset, and sign-out.
 */
object AuthManager {
    private const val TAG = "Auth"
    private val EMAIL_REGEX = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

    fun authStateFlow(auth: FirebaseAuth = Firebase.auth): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    fun ensureFirebaseAuth(context: Context): Result<FirebaseAuth> {
        return try {
            val appCtx = context.applicationContext ?: context
            val app = if (FirebaseApp.getApps(appCtx).isEmpty()) {
                FirebaseApp.initializeApp(appCtx)
            } else {
                FirebaseApp.getInstance()
            }
            if (app == null) {
                return Result.failure(
                    IllegalStateException("Firebase failed to initialize from google-services.json.")
                )
            }
            val projectId = app.options.projectId.orEmpty()
            val apiKey = app.options.apiKey
            if (projectId.isBlank() || apiKey.isBlank()) {
                return Result.failure(
                    IllegalStateException("Incomplete Firebase configuration: missing projectId or apiKey.")
                )
            }
            Result.success(FirebaseAuth.getInstance(app))
        } catch (e: Exception) {
            Log.e(TAG, "Firebase initialization error", e)
            Result.failure(IllegalStateException(mapFirebaseEmailAuthException(e), e))
        }
    }

    fun isValidEmail(rawEmail: String): Boolean {
        val trimmed = rawEmail.trim()
        return trimmed.length in 5..120 && EMAIL_REGEX.matches(trimmed)
    }

    suspend fun signInWithEmailPassword(
        email: String,
        password: String,
        auth: FirebaseAuth = Firebase.auth
    ): Result<FirebaseUser> {
        val cleanEmail = email.trim().lowercase()
        if (!isValidEmail(cleanEmail)) {
            return Result.failure(IllegalArgumentException("Enter a valid email address."))
        }
        if (password.isBlank()) {
            return Result.failure(IllegalArgumentException("Enter your password."))
        }
        return try {
            val result = auth.signInWithEmailAndPassword(cleanEmail, password).await()
            val user = result.user
                ?: return Result.failure(IllegalStateException("Sign-in succeeded without a Firebase user session."))
            // Reload user to obtain freshest emailVerified state
            try {
                user.reload().await()
            } catch (reloadErr: Exception) {
                Log.w(TAG, "User reload after sign-in warning: ${reloadErr.message}")
            }
            Result.success(auth.currentUser ?: user)
        } catch (e: Exception) {
            Log.e(TAG, "Email sign-in failed", e)
            Result.failure(IllegalStateException(mapFirebaseEmailAuthException(e), e))
        }
    }

    suspend fun createAccountWithEmailPassword(
        fullName: String,
        email: String,
        password: String,
        auth: FirebaseAuth = Firebase.auth
    ): Result<FirebaseUser> {
        val cleanName = fullName.trim()
        val cleanEmail = email.trim().lowercase()
        if (cleanName.length < 2) {
            return Result.failure(IllegalArgumentException("Enter your full name (at least 2 characters)."))
        }
        if (!isValidEmail(cleanEmail)) {
            return Result.failure(IllegalArgumentException("Enter a valid email address."))
        }
        if (password.length < 8) {
            return Result.failure(IllegalArgumentException("Password must be at least 8 characters long."))
        }
        return try {
            val result = auth.createUserWithEmailAndPassword(cleanEmail, password).await()
            val user = result.user
                ?: return Result.failure(IllegalStateException("Account created without an active user session."))
            try {
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(cleanName)
                    .build()
                user.updateProfile(profileUpdates).await()
            } catch (profileErr: Exception) {
                Log.w(TAG, "Display name update warning: ${profileErr.message}")
            }
            try {
                user.sendEmailVerification().await()
            } catch (verifyErr: Exception) {
                Log.w(TAG, "Initial verification email warning: ${verifyErr.message}")
            }
            Result.success(user)
        } catch (e: Exception) {
            Log.e(TAG, "Email registration failed", e)
            Result.failure(IllegalStateException(mapFirebaseEmailAuthException(e), e))
        }
    }

    suspend fun sendVerificationEmail(
        auth: FirebaseAuth = Firebase.auth
    ): Result<Unit> {
        val user = auth.currentUser
            ?: return Result.failure(IllegalStateException("Please sign in first to send a verification email."))
        return try {
            user.sendEmailVerification().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Send verification email failed", e)
            Result.failure(IllegalStateException(mapFirebaseEmailAuthException(e), e))
        }
    }

    suspend fun reloadAndCheckEmailVerified(
        auth: FirebaseAuth = Firebase.auth
    ): Result<Boolean> {
        val user = auth.currentUser
            ?: return Result.failure(IllegalStateException("No active user session. Please log in again."))
        return try {
            user.reload().await()
            val refreshed = auth.currentUser ?: user
            Result.success(refreshed.isEmailVerified)
        } catch (e: Exception) {
            Log.e(TAG, "Reload email verification status failed", e)
            Result.failure(IllegalStateException(mapFirebaseEmailAuthException(e), e))
        }
    }

    suspend fun sendPasswordResetEmail(
        email: String,
        auth: FirebaseAuth = Firebase.auth
    ): Result<Unit> {
        val cleanEmail = email.trim().lowercase()
        if (!isValidEmail(cleanEmail)) {
            return Result.failure(IllegalArgumentException("Enter a valid registered email address."))
        }
        return try {
            auth.sendPasswordResetEmail(cleanEmail).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Send password reset email failed", e)
            Result.failure(IllegalStateException(mapFirebaseEmailAuthException(e), e))
        }
    }

    internal fun mapFirebaseEmailAuthException(e: Exception): String {
        val chain = generateSequence<Throwable>(e) { it.cause }.take(6).toList()
        val authEx = chain.filterIsInstance<FirebaseAuthException>().firstOrNull()
        val code = authEx?.errorCode.orEmpty()
        val raw = (authEx?.localizedMessage ?: e.localizedMessage ?: e.message)?.trim().orEmpty()

        return when {
            e is FirebaseAuthWeakPasswordException || code == "ERROR_WEAK_PASSWORD" ->
                "Password is too weak. Use at least 8 characters with uppercase, lowercase, numbers, and symbols."
            e is FirebaseAuthUserCollisionException || code == "ERROR_EMAIL_ALREADY_IN_USE" ->
                "An account with this email address already exists. Use Login or Forgot Password."
            e is FirebaseAuthInvalidUserException || code == "ERROR_USER_NOT_FOUND" ->
                "No Nest Haven account was found for that email address."
            code == "ERROR_USER_DISABLED" ->
                "This account has been disabled. Contact Nest Haven support."
            e is FirebaseAuthInvalidCredentialsException ||
                code == "ERROR_WRONG_PASSWORD" ||
                code == "ERROR_INVALID_CREDENTIAL" ||
                code == "ERROR_INVALID_EMAIL" -> {
                if (code == "ERROR_INVALID_EMAIL") {
                    "Enter a valid email address."
                } else {
                    "Incorrect email or password. Check your credentials or use Forgot Password."
                }
            }
            code == "ERROR_OPERATION_NOT_ALLOWED" ->
                "Email/Password sign-in is disabled in Firebase Console. Enable Authentication -> Sign-in method -> Email/Password for project gen-lang-client-0181466425."
            chain.any { it is FirebaseTooManyRequestsException } ||
                code == "ERROR_TOO_MANY_REQUESTS" ->
                "Too many authentication attempts. Please wait a few minutes before retrying."
            chain.any { it is FirebaseNetworkException } ->
                "Network error connecting to Firebase Authentication. Check your internet connection."
            raw.isNotBlank() -> raw
            else -> "Authentication request failed. Please try again."
        }
    }

    fun signOut(
        credentialManager: CredentialManager,
        scope: CoroutineScope,
        onSignOutComplete: () -> Unit = {}
    ) {
        scope.launch {
            withContext(NonCancellable) {
                try {
                    credentialManager.clearCredentialState(ClearCredentialStateRequest())
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to clear credential state: ${e.message}")
                } finally {
                    FirebaseAuth.getInstance().signOut()
                    onSignOutComplete()
                }
            }
        }
    }
}
