package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.EventNote
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.BookingRequest
import com.example.data.model.PaymentOrder
import com.example.data.model.StayReview
import com.example.ui.components.EmptyVaultState
import com.example.ui.components.SectionHeader
import com.example.ui.components.SecurityStatusPill
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppLocalization
import com.example.ui.i18n.formatInr
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepEmerald
import com.example.ui.theme.MonoTextStyle
import com.example.ui.theme.VerifiedJade
import com.example.ui.theme.VerifiedJadeContainer

@Composable
fun TenantBookingsAndPaymentsScreen(
    language: AppLanguage,
    bookings: List<BookingRequest>,
    paymentOrders: List<PaymentOrder>,
    myReviews: List<StayReview>,
    onCancelBooking: (bookingId: String, reason: String) -> Unit,
    onCreateMonthlyRentOrder: (BookingRequest, Long) -> Unit,
    onMarkPaymentFailedOrCancelled: (orderId: String, status: String, reason: String) -> Unit,
    onSubmitReview: (BookingRequest, Long, String) -> Unit
) {
    val strings = AppLocalization.get(language)
    var activeOrderForCheckout by remember { mutableStateOf<PaymentOrder?>(null) }
    var bookingToCancel by remember { mutableStateOf<BookingRequest?>(null) }
    var bookingToReview by remember { mutableStateOf<BookingRequest?>(null) }

    val reviewedBookingIds = remember(myReviews) { myReviews.map { it.bookingId }.toSet() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(modifier = Modifier.widthIn(max = 760.dp)) {
                    SectionHeader(
                        title = "Bookings, Visits & Rent History",
                        subtitle = "${strings.firstMonthRentNotice} ${strings.secondMonthZeroFeeNotice}"
                    )
                }
            }
        }

        if (bookings.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    EmptyVaultState(
                        icon = Icons.AutoMirrored.Filled.EventNote,
                        title = "No Booking or Visit Requests Yet",
                        message = "Once verified properties are published and unlocked in your selected locality, your room bookings (2, 6, 12, or 24 months) and visit schedules appear here.",
                        modifier = Modifier.widthIn(max = 760.dp)
                    )
                }
            }
        } else {
            items(bookings, key = { it.id }) { booking ->
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    TenantBookingCard(
                        booking = booking,
                        alreadyReviewed = booking.id in reviewedBookingIds,
                        modifier = Modifier.widthIn(max = 760.dp),
                        onCancelClick = { bookingToCancel = booking },
                        onPayNextMonthRent = { month -> onCreateMonthlyRentOrder(booking, month) },
                        onReviewClick = { bookingToReview = booking }
                    )
                }
            }
        }

        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(modifier = Modifier.widthIn(max = 760.dp)) {
                    SectionHeader(
                        title = "Rent Payment Orders, Receipts & Refunds",
                        subtitle = "Verified payment history, failed attempts & 24-hour owner settlement state"
                    )
                }
            }
        }

        if (paymentOrders.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    EmptyVaultState(
                        icon = Icons.AutoMirrored.Filled.ReceiptLong,
                        title = "No Payment Orders Recorded",
                        message = "Your ₹99 search orders, first-month rent deposits, zero-fee monthly rent orders, and refund receipts appear here.",
                        modifier = Modifier.widthIn(max = 760.dp)
                    )
                }
            }
        } else {
            items(paymentOrders, key = { it.id }) { order ->
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    TenantPaymentOrderCard(
                        order = order,
                        modifier = Modifier.widthIn(max = 760.dp),
                        onOpenCheckout = { activeOrderForCheckout = order }
                    )
                }
            }
        }
    }

    activeOrderForCheckout?.let { order ->
        PaymentOrderCheckoutDialog(
            order = order,
            onDismiss = { activeOrderForCheckout = null },
            onMarkFailedOrCancelled = { status, reason ->
                onMarkPaymentFailedOrCancelled(order.id, status, reason)
                activeOrderForCheckout = null
            }
        )
    }

    bookingToCancel?.let { booking ->
        var reason by rememberSaveable { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { bookingToCancel = null },
            title = { Text("Cancel ${booking.requestType.lowercase().replaceFirstChar { it.uppercase() }}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Property: ${booking.propertyTitle}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Cancellation Reason") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCancelBooking(booking.id, reason)
                        bookingToCancel = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert)
                ) {
                    Text("Confirm Cancel")
                }
            },
            dismissButton = {
                TextButton(onClick = { bookingToCancel = null }) {
                    Text("Keep")
                }
            }
        )
    }

    bookingToReview?.let { booking ->
        StayReviewDialog(
            title = "Rate Verified Stay (${booking.ownerName})",
            onDismiss = { bookingToReview = null },
            onSubmit = { rating, comment ->
                onSubmitReview(booking, rating, comment)
                bookingToReview = null
            }
        )
    }
}

@Composable
private fun TenantBookingCard(
    booking: BookingRequest,
    alreadyReviewed: Boolean,
    modifier: Modifier = Modifier,
    onCancelClick: () -> Unit,
    onPayNextMonthRent: (Long) -> Unit,
    onReviewClick: () -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = booking.propertyTitle,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${booking.localitySummary} • ${booking.durationMonths} months • ${formatInr(booking.monthlyRentInr)}/mo",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                SecurityStatusPill(
                    label = booking.status,
                    isPositive = booking.status == "ACTIVE" || booking.status == "COMPLETED"
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(color = VerifiedJadeContainer, shape = RoundedCornerShape(8.dp)) {
                    Text(
                        text = "${booking.requestType} • Owner: ${booking.ownerDecision}",
                        style = MaterialTheme.typography.labelSmall,
                        color = DeepEmerald,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                if (booking.requestType == "BOOKING") {
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp)) {
                        Text(
                            text = if (booking.firstMonthRentPaid) "1st Month Verified" else "1st Month Unpaid",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (booking.firstMonthRentPaid) VerifiedJade else AmberWarning,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            if (booking.ownerDecisionNote.isNotBlank()) {
                Text(
                    text = "Owner note: ${booking.ownerDecisionNote}",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (booking.status in listOf("PENDING_PAYMENT", "VISIT_REQUESTED")) {
                    OutlinedButton(
                        onClick = onCancelClick,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonAlert)
                    ) {
                        Icon(Icons.Filled.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Cancel")
                    }
                }
                if (booking.status == "ACTIVE" && booking.requestType == "BOOKING") {
                    Button(
                        onClick = { onPayNextMonthRent(2L) },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald)
                    ) {
                        Icon(Icons.Filled.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Pay Monthly Rent (₹0 Fee)")
                    }
                }
                if (booking.status == "COMPLETED" && !alreadyReviewed) {
                    Button(
                        onClick = onReviewClick,
                        colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold)
                    ) {
                        Icon(Icons.Filled.Star, contentDescription = null, tint = DeepEmerald, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Rate Stay", color = DeepEmerald)
                    }
                }
            }
        }
    }
}

@Composable
private fun TenantPaymentOrderCard(
    order: PaymentOrder,
    modifier: Modifier = Modifier,
    onOpenCheckout: () -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${order.paymentPurpose.replace("_", " ")} • ${formatInr(order.amountInr)}",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                SecurityStatusPill(
                    label = order.paymentStatus,
                    isPositive = order.paymentStatus == "VERIFIED_BY_SERVER" || order.paymentStatus == "REFUNDED"
                )
            }
            Text(
                text = "Receipt: ${order.receiptRef} • Platform Fee: ${formatInr(order.platformFeeInr)} • Settlement: ${order.settlementStatus}",
                style = MonoTextStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (order.failureReason.isNotBlank()) {
                Text(
                    text = "Failure / Note: ${order.failureReason}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CrimsonAlert
                )
            }
            if (order.paymentStatus == "AWAITING_GATEWAY_VERIFICATION") {
                OutlinedButton(onClick = onOpenCheckout) {
                    Text("Open Gateway / Record Failed")
                }
            }
        }
    }
}

@Composable
fun StayReviewDialog(
    title: String,
    onDismiss: () -> Unit,
    onSubmit: (rating: Long, comment: String) -> Unit
) {
    var rating by remember { mutableLongStateOf(5L) }
    var comment by rememberSaveable { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Select rating (1–5 stars):", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    (1L..5L).forEach { star ->
                        IconButton(onClick = { rating = star }) {
                            Icon(
                                imageVector = if (star <= rating) Icons.Filled.Star else Icons.Filled.StarBorder,
                                contentDescription = "$star stars",
                                tint = ChampagneGold,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("Share honest feedback (min 3 chars)") },
                    minLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("stay_review_comment")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(rating, comment) },
                enabled = comment.trim().length >= 3,
                colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald)
            ) {
                Text("Publish Verified Review")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
