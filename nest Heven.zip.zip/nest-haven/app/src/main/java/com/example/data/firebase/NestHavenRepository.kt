package com.example.data.firebase

import com.example.data.model.BookingRequest
import com.example.data.model.NotificationItem
import com.example.data.model.PaymentOrder
import com.example.data.model.PortalRole
import com.example.data.model.PropertyRecord
import com.example.data.model.PublicSessionState
import com.example.data.model.SearchUnlock
import com.example.data.model.StayReview
import com.example.data.model.UiState
import com.example.data.model.UserSecurityProfile
import com.example.data.model.ComplaintTicket
import com.example.security.SecurityCrypto
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class NestHavenRepository(
    private val db: FirebaseFirestore
) {
    private val publicDirRef = db.collection("governance").document("public_directory")
    private val usersCol = db.collection("users")
    private val accountClaimsCol = db.collection("account_claims")
    private val propertiesCol = db.collection("properties")
    private val searchUnlocksCol = db.collection("search_unlocks")
    private val bookingsCol = db.collection("bookings")
    private val paymentOrdersCol = db.collection("payment_orders")
    private val notificationsCol = db.collection("notifications")
    private val complaintsCol = db.collection("complaints")
    private val reviewsCol = db.collection("reviews")
    private val auditLogsCol = db.collection("audit_logs")

    suspend fun registerEmailPasswordUserAccount(
        fullName: String,
        email: String,
        accountType: PortalRole = PortalRole.TENANT,
        preferredLanguageCode: String = "en"
    ): Result<UserSecurityProfile> {
        val currentUser = Firebase.auth.currentUser
            ?: return Result.failure(IllegalStateException("Account authentication failed. Please try registering again."))
        val uid = currentUser.uid
        val cleanName = fullName.trim().take(100)
        if (cleanName.length < 2) {
            return Result.failure(IllegalArgumentException("Full name is required."))
        }
        val cleanEmail = email.trim().lowercase().take(120)
        if (!AuthManager.isValidEmail(cleanEmail)) {
            return Result.failure(IllegalArgumentException("Valid email address is required."))
        }
        val authEmail = currentUser.email?.trim()?.lowercase().orEmpty()
        if (authEmail.isNotBlank() && authEmail != cleanEmail) {
            return Result.failure(IllegalStateException("Authenticated email address mismatch."))
        }

        val langCode = if (preferredLanguageCode == "hi") "hi" else "en"
        val emailClaimId = "email_${SecurityCrypto.sha256Hex(cleanEmail)}"

        return try {
            val existingEmailClaim = accountClaimsCol.document(emailClaimId).get().await()
            if (existingEmailClaim.exists() && existingEmailClaim.getString("ownerUid") != uid) {
                return Result.failure(
                    IllegalStateException("An account with this email address already exists. Please log in instead.")
                )
            }

            val existingProfile = usersCol.document(uid).get().await()
            if (existingProfile.exists()) {
                return Result.success(
                    existingProfile.toObject(UserSecurityProfile::class.java)
                        ?: UserSecurityProfile(
                            id = uid,
                            userId = uid,
                            email = cleanEmail,
                            displayName = cleanName,
                            phone = "",
                            accountType = accountType.name,
                            preferredLanguage = langCode
                        )
                )
            }

            val masterUid = try {
                val dirSnap = publicDirRef.get().await()
                if (dirSnap.exists()) dirSnap.getString("masterUid").orEmpty() else ""
            } catch (_: Exception) {
                ""
            }

            val batch = db.batch()
            if (!existingEmailClaim.exists()) {
                batch.set(
                    accountClaimsCol.document(emailClaimId),
                    mapOf(
                        "ownerUid" to uid,
                        "claimType" to "EMAIL",
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            val userPayload = mapOf(
                "userId" to uid,
                "email" to cleanEmail,
                "displayName" to cleanName,
                "phone" to "",
                "accountType" to accountType.name,
                "preferredLanguage" to langCode,
                "role" to "MEMBER",
                "ownerApproved" to false,
                "kycVerified" to false,
                "vaultPasswordHash" to "",
                "vaultPasswordSalt" to "",
                "totpEnabled" to false,
                "recoveryCodesCount" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            batch.set(usersCol.document(uid), userPayload)
            batch.commit().await()

            appendPublicAuditLogIfConfigured(
                masterUid = masterUid,
                actorUid = uid,
                actorEmail = cleanEmail,
                actorRole = accountType.name,
                action = "USER_REGISTERED",
                targetType = "USER_PROFILE",
                targetId = uid,
                summary = "Registered Email/Password ${accountType.name} account ($cleanEmail)",
                severity = "INFO"
            )

            val created = usersCol.document(uid).get().await().toObject(UserSecurityProfile::class.java)
                ?: UserSecurityProfile(
                    id = uid,
                    userId = uid,
                    email = cleanEmail,
                    displayName = cleanName,
                    phone = "",
                    accountType = accountType.name,
                    preferredLanguage = langCode
                )
            Result.success(created)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val details = handleFirestoreError(e, OperationType.CREATE, "users/$uid")
            Result.failure(IllegalStateException(details, e))
        }
    }

    suspend fun loadOrCreatePublicSession(
        preferredRole: PortalRole,
        preferredLanguageCode: String,
        registrationName: String = "",
        registrationPhone: String = ""
    ): Result<PublicSessionState> {
        val currentUser = Firebase.auth.currentUser
            ?: return Result.failure(IllegalStateException("Not authenticated"))
        val uid = currentUser.uid
        val authEmail = (currentUser.email?.takeIf { it.isNotBlank() } ?: "user@nesthaven.in").take(120)
        val cleanRegName = registrationName.trim().take(100)
        val cleanRegPhone = registrationPhone.trim().take(20)
        val fallbackName = cleanRegName.ifBlank {
            currentUser.displayName?.takeIf { it.isNotBlank() }
                ?: authEmail.substringBefore("@").ifBlank { "Nest Haven User" }
        }
        val langCode = if (preferredLanguageCode == "hi") "hi" else "en"

        val masterUid = try {
            val dirSnap = publicDirRef.get().await()
            if (dirSnap.exists()) dirSnap.getString("masterUid").orEmpty() else ""
        } catch (_: Exception) {
            ""
        }

        return try {
            val userDocRef = usersCol.document(uid)
            val snap = userDocRef.get().await()
            val profile = if (snap.exists()) {
                val existing = snap.toObject(UserSecurityProfile::class.java)
                    ?: throw IllegalStateException("Unable to read profile.")
                val updates = mutableMapOf<String, Any>(
                    "accountType" to preferredRole.name,
                    "preferredLanguage" to langCode,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (cleanRegName.isNotBlank()) updates["displayName"] = cleanRegName
                if (cleanRegPhone.isNotBlank() && existing.phone.isBlank()) updates["phone"] = cleanRegPhone
                userDocRef.update(updates).await()
                existing.copy(
                    accountType = preferredRole.name,
                    preferredLanguage = langCode,
                    displayName = cleanRegName.ifBlank { existing.displayName },
                    phone = existing.phone.ifBlank { cleanRegPhone }
                )
            } else {
                val payload = mapOf(
                    "userId" to uid,
                    "email" to authEmail,
                    "displayName" to fallbackName.take(100),
                    "phone" to cleanRegPhone,
                    "accountType" to preferredRole.name,
                    "preferredLanguage" to langCode,
                    "role" to "MEMBER",
                    "ownerApproved" to false,
                    "kycVerified" to false,
                    "vaultPasswordHash" to "",
                    "vaultPasswordSalt" to "",
                    "totpEnabled" to false,
                    "recoveryCodesCount" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                userDocRef.set(payload).await()
                appendPublicAuditLogIfConfigured(
                    masterUid = masterUid,
                    actorUid = uid,
                    actorEmail = authEmail,
                    actorRole = preferredRole.name,
                    action = "USER_REGISTERED",
                    targetType = "USER_PROFILE",
                    targetId = uid,
                    summary = "Registered public ${preferredRole.name} account ($authEmail)",
                    severity = "INFO"
                )
                userDocRef.get().await().toObject(UserSecurityProfile::class.java)
                    ?: UserSecurityProfile(
                        id = uid,
                        userId = uid,
                        email = authEmail,
                        displayName = fallbackName,
                        phone = cleanRegPhone,
                        accountType = preferredRole.name,
                        preferredLanguage = langCode
                    )
            }

            Result.success(
                PublicSessionState(
                    uid = uid,
                    email = profile.email.ifBlank { authEmail },
                    displayName = profile.displayName.ifBlank { fallbackName },
                    profile = profile,
                    masterUid = masterUid
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val details = handleFirestoreError(e, OperationType.GET, "users/$uid")
            Result.failure(IllegalStateException(details, e))
        }
    }

    fun observeUserProfile(uid: String): Flow<UiState<UserSecurityProfile?>> = callbackFlow {
        val reg = usersCol.document(uid).addSnapshotListener { snapshot, error ->
            if (error != null) {
                handleFirestoreError(error, OperationType.GET, "users/$uid")
                trySend(UiState.Error(error.localizedMessage ?: "Failed to load user profile"))
                return@addSnapshotListener
            }
            val profile = snapshot?.toObject(UserSecurityProfile::class.java)
            trySend(UiState.Success(profile))
        }
        awaitClose { reg.remove() }
    }

    fun observePublishedProperties(): Flow<UiState<List<PropertyRecord>>> = observeQueryList(
        query = propertiesCol.whereEqualTo("published", true),
        path = "properties(published)"
    ) { doc ->
        doc.toObject(PropertyRecord::class.java)
    }

    fun observeOwnerProperties(ownerUid: String): Flow<UiState<List<PropertyRecord>>> = observeQueryList(
        query = propertiesCol.whereEqualTo("ownerUid", ownerUid),
        path = "properties(owner=$ownerUid)"
    ) { doc ->
        doc.toObject(PropertyRecord::class.java)
    }

    fun observeTenantSearchUnlocks(tenantUid: String): Flow<UiState<List<SearchUnlock>>> = observeQueryList(
        query = searchUnlocksCol.whereEqualTo("tenantUid", tenantUid),
        path = "search_unlocks($tenantUid)",
        sorter = { list -> list.sortedByDescending { it.createdAt?.seconds ?: Long.MAX_VALUE } }
    ) { doc ->
        doc.toObject(SearchUnlock::class.java)
    }

    fun observeTenantBookings(tenantUid: String): Flow<UiState<List<BookingRequest>>> = observeQueryList(
        query = bookingsCol.whereEqualTo("tenantUid", tenantUid),
        path = "bookings(tenant=$tenantUid)",
        sorter = { list -> list.sortedByDescending { it.createdAt?.seconds ?: Long.MAX_VALUE } }
    ) { doc ->
        doc.toObject(BookingRequest::class.java)
    }

    fun observeOwnerBookings(ownerUid: String): Flow<UiState<List<BookingRequest>>> = observeQueryList(
        query = bookingsCol.whereEqualTo("ownerUid", ownerUid),
        path = "bookings(owner=$ownerUid)",
        sorter = { list -> list.sortedByDescending { it.createdAt?.seconds ?: Long.MAX_VALUE } }
    ) { doc ->
        doc.toObject(BookingRequest::class.java)
    }

    fun observeTenantPaymentOrders(tenantUid: String): Flow<UiState<List<PaymentOrder>>> = observeQueryList(
        query = paymentOrdersCol.whereEqualTo("tenantUid", tenantUid),
        path = "payment_orders(tenant=$tenantUid)",
        sorter = { list -> list.sortedByDescending { it.createdAt?.seconds ?: Long.MAX_VALUE } }
    ) { doc ->
        doc.toObject(PaymentOrder::class.java)
    }

    fun observeOwnerPaymentOrders(ownerUid: String): Flow<UiState<List<PaymentOrder>>> = observeQueryList(
        query = paymentOrdersCol.whereEqualTo("ownerUid", ownerUid),
        path = "payment_orders(owner=$ownerUid)",
        sorter = { list -> list.sortedByDescending { it.createdAt?.seconds ?: Long.MAX_VALUE } }
    ) { doc ->
        doc.toObject(PaymentOrder::class.java)
    }

    fun observeNotifications(uid: String): Flow<UiState<List<NotificationItem>>> = observeQueryList(
        query = notificationsCol.whereEqualTo("recipientUid", uid),
        path = "notifications($uid)",
        sorter = { list -> list.sortedByDescending { it.createdAt?.seconds ?: Long.MAX_VALUE } }
    ) { doc ->
        doc.toObject(NotificationItem::class.java)
    }

    fun observeMyComplaints(uid: String): Flow<UiState<List<ComplaintTicket>>> = observeQueryList(
        query = complaintsCol.whereEqualTo("reporterUid", uid),
        path = "complaints($uid)",
        sorter = { list -> list.sortedByDescending { it.createdAt?.seconds ?: Long.MAX_VALUE } }
    ) { doc ->
        doc.toObject(ComplaintTicket::class.java)
    }

    fun observeReviewsByReviewer(uid: String): Flow<UiState<List<StayReview>>> = observeQueryList(
        query = reviewsCol.whereEqualTo("reviewerUid", uid),
        path = "reviews(by=$uid)",
        sorter = { list -> list.sortedByDescending { it.createdAt?.seconds ?: Long.MAX_VALUE } }
    ) { doc ->
        doc.toObject(StayReview::class.java)
    }

    fun observeReviewsForTarget(targetUid: String): Flow<UiState<List<StayReview>>> = observeQueryList(
        query = reviewsCol.whereEqualTo("targetUid", targetUid),
        path = "reviews(target=$targetUid)",
        sorter = { list -> list.sortedByDescending { it.createdAt?.seconds ?: Long.MAX_VALUE } }
    ) { doc ->
        doc.toObject(StayReview::class.java)
    }

    suspend fun updateProfilePreferences(
        uid: String,
        displayName: String,
        phone: String,
        accountType: PortalRole,
        preferredLanguageCode: String
    ): Result<Unit> {
        val cleanName = displayName.trim().take(100)
        if (cleanName.isBlank()) return Result.failure(IllegalArgumentException("Display name cannot be empty."))
        val cleanPhone = phone.trim().take(20)
        val lang = if (preferredLanguageCode == "hi") "hi" else "en"
        return try {
            usersCol.document(uid).update(
                mapOf(
                    "displayName" to cleanName,
                    "phone" to cleanPhone,
                    "accountType" to accountType.name,
                    "preferredLanguage" to lang,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$uid")
            Result.failure(e)
        }
    }

    suspend fun updateOptionalSecurityProtection(
        uid: String,
        email: String,
        masterUid: String,
        roleLabel: String,
        passwordHash: String,
        passwordSalt: String,
        totpEnabled: Boolean,
        recoveryCodesCount: Long
    ): Result<Unit> {
        return try {
            usersCol.document(uid).update(
                mapOf(
                    "vaultPasswordHash" to passwordHash,
                    "vaultPasswordSalt" to passwordSalt,
                    "totpEnabled" to totpEnabled,
                    "recoveryCodesCount" to recoveryCodesCount.coerceIn(0L, 10L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            appendPublicAuditLogIfConfigured(
                masterUid = masterUid,
                actorUid = uid,
                actorEmail = email,
                actorRole = roleLabel,
                action = "USER_SECURITY_SETUP",
                targetType = "USER_PROFILE",
                targetId = uid,
                summary = "Updated optional account 2FA & passphrase protection",
                severity = "SECURITY"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$uid")
            Result.failure(e)
        }
    }

    suspend fun createSearchUnlockAndOrder99(
        tenantUid: String,
        actorEmail: String,
        masterUid: String,
        state: String,
        city: String,
        locality: String,
        buildingFilter: String,
        monthlyBudgetInr: Long,
        roomPreference: String,
        requiredFacilities: List<String>
    ): Result<Pair<String, String>> {
        val unlockId = "unlock_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val orderId = "ord99_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val receiptRef = "NH99-${orderId.takeLast(8).uppercase()}"
        val clampedBudget = monthlyBudgetInr.coerceIn(500L, 1_000_000L)
        val cleanRoomPref = if (roomPreference in listOf("SINGLE", "DOUBLE", "ANY")) roomPreference else "ANY"
        val cleanFacilities = requiredFacilities.map { it.trim() }.filter { it.isNotBlank() }.take(15)

        return try {
            val batch = db.batch()
            val unlockPayload = mapOf(
                "tenantUid" to tenantUid,
                "state" to state.trim().take(64),
                "city" to city.trim().take(64),
                "locality" to locality.trim().take(80),
                "buildingFilter" to buildingFilter.trim().take(100),
                "monthlyBudgetInr" to clampedBudget,
                "roomPreference" to cleanRoomPref,
                "requiredFacilities" to cleanFacilities,
                "feeAmountInr" to 99L,
                "unlockStatus" to "PAYMENT_PENDING",
                "alternativeOffered" to false,
                "alternativeRentInr" to 0L,
                "alternativeAccepted" to false,
                "refundStatus" to "NONE",
                "paymentOrderId" to orderId,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val orderPayload = mapOf(
                "tenantUid" to tenantUid,
                "ownerUid" to "",
                "bookingId" to "",
                "searchUnlockId" to unlockId,
                "paymentPurpose" to "SEARCH_FEE_99",
                "amountInr" to 99L,
                "platformFeeInr" to 99L,
                "rentMonthNumber" to 0L,
                "paymentStatus" to "AWAITING_GATEWAY_VERIFICATION",
                "settlementStatus" to "NOT_APPLICABLE",
                "ownerVerifiedReceipt" to false,
                "receiptRef" to receiptRef,
                "failureReason" to "",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            val notifPayload = mapOf(
                "recipientUid" to tenantUid,
                "category" to "PAYMENT",
                "title" to "₹99 Locality Search Order Created",
                "message" to "Order $receiptRef for $locality, $city created. Awaiting verified gateway capture before unlocking listings.",
                "readFlag" to false,
                "createdAt" to FieldValue.serverTimestamp()
            )
            batch.set(searchUnlocksCol.document(unlockId), unlockPayload)
            batch.set(paymentOrdersCol.document(orderId), orderPayload)
            batch.set(notificationsCol.document(notifId), notifPayload)
            batch.commit().await()

            appendPublicAuditLogIfConfigured(
                masterUid = masterUid,
                actorUid = tenantUid,
                actorEmail = actorEmail,
                actorRole = "TENANT",
                action = "PAYMENT_ORDER_CREATED",
                targetType = "PAYMENT_ORDER",
                targetId = orderId,
                summary = "Created ₹99 search fee order for $locality, $city ($state)",
                severity = "INFO"
            )
            Result.success(unlockId to orderId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "search_unlocks/$unlockId")
            Result.failure(e)
        }
    }

    suspend fun markPaymentOrderFailedOrCancelled(
        orderId: String,
        newStatus: String,
        reason: String
    ): Result<Unit> {
        val status = if (newStatus == "CANCELLED") "CANCELLED" else "FAILED"
        val cleanReason = reason.trim().ifBlank { "Payment not completed at gateway" }.take(240)
        return try {
            paymentOrdersCol.document(orderId).update(
                mapOf(
                    "paymentStatus" to status,
                    "failureReason" to cleanReason,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "payment_orders/$orderId")
            Result.failure(e)
        }
    }

    suspend fun acceptSearchAlternative(unlockId: String): Result<Unit> {
        return try {
            searchUnlocksCol.document(unlockId).update(
                mapOf(
                    "alternativeAccepted" to true,
                    "refundStatus" to "NOT_ELIGIBLE_ALTERNATIVE_ACCEPTED",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "search_unlocks/$unlockId")
            Result.failure(e)
        }
    }

    suspend fun requestSearchRefundVerification(unlockId: String, tenantUid: String): Result<Unit> {
        return try {
            val batch = db.batch()
            batch.update(
                searchUnlocksCol.document(unlockId),
                mapOf(
                    "refundStatus" to "UNDER_VERIFICATION",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            batch.set(
                notificationsCol.document(notifId),
                mapOf(
                    "recipientUid" to tenantUid,
                    "category" to "REFUND",
                    "title" to "₹99 Refund Under Verification",
                    "message" to "Your ₹99 search refund claim is queued for anti-fraud review.",
                    "readFlag" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "search_unlocks/$unlockId")
            Result.failure(e)
        }
    }

    suspend fun createBookingOrVisitRequest(
        property: PropertyRecord,
        tenantUid: String,
        tenantName: String,
        tenantEmail: String,
        masterUid: String,
        requestType: String,
        durationMonths: Long
    ): Result<String> {
        if (property.id.isBlank() || property.ownerUid.isBlank()) {
            return Result.failure(IllegalArgumentException("Verified owner details required for booking."))
        }
        val cleanType = if (requestType == "VISIT") "VISIT" else "BOOKING"
        val cleanDuration = if (durationMonths in listOf(2L, 6L, 12L, 24L)) durationMonths else 6L
        val bookingId = "bkg_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val initialStatus = if (cleanType == "VISIT") "VISIT_REQUESTED" else "PENDING_PAYMENT"
        val localitySummary = listOf(property.locality, property.city, property.state)
            .filter { it.isNotBlank() }
            .joinToString(", ")
            .take(160)

        return try {
            val batch = db.batch()
            val bookingPayload = mapOf(
                "propertyId" to property.id,
                "propertyTitle" to "${property.name} (Room ${property.roomNumber})".take(120),
                "localitySummary" to localitySummary,
                "tenantUid" to tenantUid,
                "tenantName" to tenantName.ifBlank { "Tenant" }.take(100),
                "ownerUid" to property.ownerUid,
                "ownerName" to property.ownerName.ifBlank { "Verified Owner" }.take(100),
                "requestType" to cleanType,
                "durationMonths" to cleanDuration,
                "monthlyRentInr" to property.monthlyRentInr.coerceIn(500L, 1_000_000L),
                "firstMonthRentPaid" to false,
                "status" to initialStatus,
                "ownerDecision" to "PENDING",
                "ownerDecisionNote" to "",
                "cancellationReason" to "",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            batch.set(bookingsCol.document(bookingId), bookingPayload)

            if (cleanType == "BOOKING") {
                val orderId = "ord1m_${UUID.randomUUID().toString().replace("-", "").take(16)}"
                val receiptRef = "NH1M-${orderId.takeLast(8).uppercase()}"
                batch.set(
                    paymentOrdersCol.document(orderId),
                    mapOf(
                        "tenantUid" to tenantUid,
                        "ownerUid" to property.ownerUid,
                        "bookingId" to bookingId,
                        "searchUnlockId" to "",
                        "paymentPurpose" to "FIRST_MONTH_RENT",
                        "amountInr" to property.monthlyRentInr.coerceIn(500L, 1_000_000L),
                        "platformFeeInr" to 0L,
                        "rentMonthNumber" to 1L,
                        "paymentStatus" to "AWAITING_GATEWAY_VERIFICATION",
                        "settlementStatus" to "PENDING_VERIFICATION",
                        "ownerVerifiedReceipt" to false,
                        "receiptRef" to receiptRef,
                        "failureReason" to "",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }

            val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            batch.set(
                notificationsCol.document(notifId),
                mapOf(
                    "recipientUid" to tenantUid,
                    "category" to "BOOKING",
                    "title" to if (cleanType == "VISIT") "Visit Request Submitted" else "Booking & 1st Month Rent Order Created",
                    "message" to if (cleanType == "VISIT") {
                        "Visit request sent for ${property.name} in $localitySummary."
                    } else {
                        "Booking created for $cleanDuration months. Complete verified 1st-month rent payment before owner approval."
                    },
                    "readFlag" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()

            if (cleanType == "BOOKING") {
                appendPublicAuditLogIfConfigured(
                    masterUid = masterUid,
                    actorUid = tenantUid,
                    actorEmail = tenantEmail,
                    actorRole = "TENANT",
                    action = "PAYMENT_ORDER_CREATED",
                    targetType = "BOOKING",
                    targetId = bookingId,
                    summary = "Created $cleanDuration-month booking & 1st-month rent order for ${property.name}",
                    severity = "INFO"
                )
            }
            Result.success(bookingId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "bookings/$bookingId")
            Result.failure(e)
        }
    }

    suspend fun createMonthlyRentOrder(
        booking: BookingRequest,
        monthNumber: Long,
        tenantEmail: String,
        masterUid: String
    ): Result<String> {
        val cleanMonth = monthNumber.coerceIn(1L, booking.durationMonths.coerceAtLeast(1L))
        val purpose = if (cleanMonth == 1L) "FIRST_MONTH_RENT" else "MONTHLY_RENT"
        val orderId = "ordm${cleanMonth}_${UUID.randomUUID().toString().replace("-", "").take(14)}"
        val receiptRef = "NHR$cleanMonth-${orderId.takeLast(8).uppercase()}"

        return try {
            val batch = db.batch()
            batch.set(
                paymentOrdersCol.document(orderId),
                mapOf(
                    "tenantUid" to booking.tenantUid,
                    "ownerUid" to booking.ownerUid,
                    "bookingId" to booking.id,
                    "searchUnlockId" to "",
                    "paymentPurpose" to purpose,
                    "amountInr" to booking.monthlyRentInr.coerceIn(500L, 1_000_000L),
                    "platformFeeInr" to 0L, // ₹0 platform charges from month 2 onward
                    "rentMonthNumber" to cleanMonth,
                    "paymentStatus" to "AWAITING_GATEWAY_VERIFICATION",
                    "settlementStatus" to "PENDING_VERIFICATION",
                    "ownerVerifiedReceipt" to false,
                    "receiptRef" to receiptRef,
                    "failureReason" to "",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            batch.set(
                notificationsCol.document(notifId),
                mapOf(
                    "recipientUid" to booking.tenantUid,
                    "category" to "RENT_REMINDER",
                    "title" to "Month $cleanMonth Rent Order Ready",
                    "message" to "Receipt $receiptRef created with ₹0 platform fee. Awaiting payment gateway verification.",
                    "readFlag" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()

            appendPublicAuditLogIfConfigured(
                masterUid = masterUid,
                actorUid = booking.tenantUid,
                actorEmail = tenantEmail,
                actorRole = "TENANT",
                action = "PAYMENT_ORDER_CREATED",
                targetType = "PAYMENT_ORDER",
                targetId = orderId,
                summary = "Created Month $cleanMonth rent order (${booking.propertyTitle})",
                severity = "INFO"
            )
            Result.success(orderId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "payment_orders/$orderId")
            Result.failure(e)
        }
    }

    suspend fun cancelTenantBooking(bookingId: String, reason: String): Result<Unit> {
        val cleanReason = reason.trim().ifBlank { "Cancelled by tenant" }.take(300)
        return try {
            bookingsCol.document(bookingId).update(
                mapOf(
                    "status" to "CANCELLED",
                    "cancellationReason" to cleanReason,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "bookings/$bookingId")
            Result.failure(e)
        }
    }

    suspend fun submitOwnerBookingDecision(
        booking: BookingRequest,
        approved: Boolean,
        note: String
    ): Result<Unit> {
        if (booking.requestType == "BOOKING" && !booking.firstMonthRentPaid) {
            return Result.failure(
                IllegalStateException("First month's rent must be server-verified before confirming a booking.")
            )
        }
        val decision = if (approved) "APPROVED" else "REJECTED"
        val newStatus = if (approved) "ACTIVE" else "CANCELLED"
        val cleanNote = note.trim().take(300)

        return try {
            val batch = db.batch()
            batch.update(
                bookingsCol.document(booking.id),
                mapOf(
                    "ownerDecision" to decision,
                    "ownerDecisionNote" to cleanNote,
                    "status" to newStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            batch.set(
                notificationsCol.document(notifId),
                mapOf(
                    "recipientUid" to booking.tenantUid,
                    "category" to "BOOKING",
                    "title" to if (approved) "Request Approved by Owner" else "Request Declined by Owner",
                    "message" to "${booking.propertyTitle}: Owner marked your ${booking.requestType.lowercase()} as $decision. $cleanNote".trim(),
                    "readFlag" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "bookings/${booking.id}")
            Result.failure(e)
        }
    }

    suspend fun acknowledgeVerifiedRentReceipt(order: PaymentOrder): Result<Unit> {
        if (order.paymentStatus != "VERIFIED_BY_SERVER") {
            return Result.failure(IllegalStateException("Only server-verified payments can be acknowledged."))
        }
        return try {
            val batch = db.batch()
            batch.update(
                paymentOrdersCol.document(order.id),
                mapOf(
                    "ownerVerifiedReceipt" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            batch.set(
                notificationsCol.document(notifId),
                mapOf(
                    "recipientUid" to order.tenantUid,
                    "category" to "PAYMENT",
                    "title" to "Rent Receipt Verified by Owner",
                    "message" to "Owner confirmed receipt ${order.receiptRef}.",
                    "readFlag" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "payment_orders/${order.id}")
            Result.failure(e)
        }
    }

    suspend fun markNotificationRead(notifId: String): Result<Unit> {
        return try {
            notificationsCol.document(notifId).update("readFlag", true).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "notifications/$notifId")
            Result.failure(e)
        }
    }

    suspend fun submitComplaint(
        reporterUid: String,
        reporterRole: PortalRole,
        reporterName: String,
        reporterEmail: String,
        masterUid: String,
        category: String,
        subject: String,
        description: String
    ): Result<String> {
        val cleanSubject = subject.trim().take(120)
        val cleanDescription = description.trim().take(1000)
        if (cleanSubject.length < 3 || cleanDescription.length < 5) {
            return Result.failure(IllegalArgumentException("Please provide a subject and detailed description."))
        }
        val cleanCategory = if (category in listOf("PROPERTY", "PAYMENT", "REFUND", "SAFETY", "OWNER_TENANT", "OTHER")) {
            category
        } else {
            "OTHER"
        }
        val complaintId = "cmp_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        return try {
            complaintsCol.document(complaintId).set(
                mapOf(
                    "reporterUid" to reporterUid,
                    "reporterRole" to reporterRole.name,
                    "reporterName" to reporterName.ifBlank { "Nest Haven User" }.take(100),
                    "category" to cleanCategory,
                    "subject" to cleanSubject,
                    "description" to cleanDescription,
                    "status" to "OPEN",
                    "adminResolutionNote" to "",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            appendPublicAuditLogIfConfigured(
                masterUid = masterUid,
                actorUid = reporterUid,
                actorEmail = reporterEmail,
                actorRole = reporterRole.name,
                action = "COMPLAINT_SUBMITTED",
                targetType = "COMPLAINT",
                targetId = complaintId,
                summary = "Complaint filed ($cleanCategory): $cleanSubject",
                severity = "INFO"
            )
            Result.success(complaintId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "complaints/$complaintId")
            Result.failure(e)
        }
    }

    suspend fun submitStayReview(
        booking: BookingRequest,
        reviewerUid: String,
        reviewerRole: PortalRole,
        rating: Long,
        comment: String
    ): Result<Unit> {
        if (booking.status != "COMPLETED") {
            return Result.failure(IllegalStateException("Ratings are allowed only after a completed stay."))
        }
        val cleanComment = comment.trim().take(500)
        if (cleanComment.length < 3) {
            return Result.failure(IllegalArgumentException("Please enter a short review comment."))
        }
        val targetUid = if (reviewerRole == PortalRole.TENANT) booking.ownerUid else booking.tenantUid
        val reviewId = "${booking.id}_$reviewerUid"
        return try {
            reviewsCol.document(reviewId).set(
                mapOf(
                    "bookingId" to booking.id,
                    "reviewerUid" to reviewerUid,
                    "reviewerRole" to reviewerRole.name,
                    "targetUid" to targetUid,
                    "rating" to rating.coerceIn(1L, 5L),
                    "comment" to cleanComment,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "reviews/$reviewId")
            Result.failure(e)
        }
    }

    private suspend fun appendPublicAuditLogIfConfigured(
        masterUid: String,
        actorUid: String,
        actorEmail: String,
        actorRole: String,
        action: String,
        targetType: String,
        targetId: String,
        summary: String,
        severity: String
    ) {
        if (masterUid.isBlank()) return
        val logId = "aud_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        try {
            auditLogsCol.document(logId).set(
                mapOf(
                    "masterUid" to masterUid,
                    "actorUid" to actorUid,
                    "actorEmail" to actorEmail.take(120),
                    "actorRole" to actorRole,
                    "action" to action,
                    "targetType" to targetType,
                    "targetId" to targetId,
                    "summary" to summary.take(400),
                    "severity" to severity,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (_: Exception) {
            // Do not block public user workflows if Master directory hasn't been initialized yet
        }
    }

    private fun <T> observeQueryList(
        query: Query,
        path: String,
        sorter: ((List<T>) -> List<T>)? = null,
        mapper: (DocumentSnapshot) -> T?
    ): Flow<UiState<List<T>>> = callbackFlow {
        val reg = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                handleFirestoreError(error, OperationType.LIST, path)
                trySend(UiState.Error(error.localizedMessage ?: "Failed to sync data"))
                return@addSnapshotListener
            }
            val items = snapshot?.documents?.mapNotNull(mapper).orEmpty()
            trySend(UiState.Success(sorter?.invoke(items) ?: items))
        }
        awaitClose { reg.remove() }
    }
}
