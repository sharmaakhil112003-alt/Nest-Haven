package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.firebase.AuthManager
import com.example.data.firebase.NestHavenRepository
import com.example.data.model.PortalRole
import com.example.security.SecurityCrypto
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppLocalization
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneGoldSoft
import com.example.ui.theme.DeepEmerald
import com.example.ui.theme.VerifiedJade
import com.example.ui.theme.VerifiedJadeContainer
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun RegistrationFormSection(
    language: AppLanguage,
    onBackToLogin: () -> Unit,
    onRegistrationSuccess: (role: PortalRole, name: String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val strings = AppLocalization.get(language)

    var fullName by rememberSaveable { mutableStateOf("") }
    var emailInput by rememberSaveable { mutableStateOf("") }
    var passwordInput by rememberSaveable { mutableStateOf("") }
    var confirmPasswordInput by rememberSaveable { mutableStateOf("") }
    var passwordVisible by rememberSaveable { mutableStateOf(false) }
    var confirmPasswordVisible by rememberSaveable { mutableStateOf(false) }
    var selectedRole by rememberSaveable { mutableStateOf(PortalRole.TENANT) }

    var pendingVerificationEmail by rememberSaveable { mutableStateOf<String?>(null) }
    var resendCooldown by rememberSaveable { mutableIntStateOf(0) }
    var isCreatingAccount by remember { mutableStateOf(false) }
    var isCheckingVerification by remember { mutableStateOf(false) }
    var formError by remember { mutableStateOf<String?>(null) }
    var formInfo by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(resendCooldown) {
        if (resendCooldown > 0) {
            delay(1000L)
            resendCooldown -= 1
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (pendingVerificationEmail != null) {
            // Post-registration Email Verification step
            Surface(
                color = VerifiedJadeContainer.copy(alpha = 0.7f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, VerifiedJade),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("reg_verification_panel")
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.MarkEmailRead, contentDescription = null, tint = VerifiedJade)
                        Text(
                            text = strings.verifyEmailTitle,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = DeepEmerald
                        )
                    }
                    Text(
                        text = "Your account has been created and a verification link was sent to ${pendingVerificationEmail}. Click the link in your inbox (or spam folder), then tap Continue below.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DeepEmerald
                    )
                }
            }

            Button(
                onClick = {
                    isCheckingVerification = true
                    formError = null
                    scope.launch {
                        AuthManager.reloadAndCheckEmailVerified().fold(
                            onSuccess = { verified ->
                                isCheckingVerification = false
                                if (verified) {
                                    onRegistrationSuccess(selectedRole, fullName.trim())
                                } else {
                                    formError = "Email is not verified yet. Please click the verification link in ${pendingVerificationEmail} first."
                                }
                            },
                            onFailure = { err ->
                                isCheckingVerification = false
                                formError = err.localizedMessage ?: "Unable to verify status right now."
                            }
                        )
                    }
                },
                enabled = !isCheckingVerification,
                colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .minimumInteractiveComponentSize()
                    .testTag("reg_check_verified_button")
            ) {
                if (isCheckingVerification) {
                    CircularProgressIndicator(Modifier.size(18.dp), color = ChampagneGoldSoft, strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                }
                Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(strings.checkVerifiedLabel, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = {
                    isCheckingVerification = true
                    formError = null
                    scope.launch {
                        AuthManager.sendVerificationEmail().fold(
                            onSuccess = {
                                isCheckingVerification = false
                                resendCooldown = 60
                                formInfo = "Verification email resent to ${pendingVerificationEmail}."
                            },
                            onFailure = { err ->
                                isCheckingVerification = false
                                formError = err.localizedMessage ?: "Unable to resend verification email."
                            }
                        )
                    }
                },
                enabled = resendCooldown == 0 && !isCheckingVerification,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .minimumInteractiveComponentSize()
                    .testTag("reg_resend_verification_button")
            ) {
                Text(
                    if (resendCooldown > 0) "${strings.resendVerificationLabel} (${resendCooldown}s)"
                    else strings.resendVerificationLabel
                )
            }

            TextButton(
                onClick = onBackToLogin,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .testTag("back_to_login_button")
            ) {
                Text("Back to Login")
            }
        } else {
            Text(
                text = "Create New Nest Haven Account",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = DeepEmerald
            )
            Text(
                text = "Register with your email and password. A verification email will be sent to activate your account.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it; formError = null },
                label = { Text("Full Name") },
                leadingIcon = { Icon(Icons.Filled.Person, contentDescription = "Full Name") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("reg_fullname_input")
            )

            OutlinedTextField(
                value = emailInput,
                onValueChange = { emailInput = it; formError = null },
                label = { Text("Email Address") },
                leadingIcon = { Icon(Icons.Filled.Email, contentDescription = "Email Address") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("reg_email_input")
            )

            OutlinedTextField(
                value = passwordInput,
                onValueChange = { passwordInput = it; formError = null },
                label = { Text("Create Password") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Password") },
                trailingIcon = {
                    IconButton(
                        onClick = { passwordVisible = !passwordVisible },
                        modifier = Modifier.testTag("reg_password_visibility_toggle")
                    ) {
                        Icon(
                            imageVector = if (passwordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = if (passwordVisible) "Hide Password" else "Show Password"
                        )
                    }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("reg_password_input")
            )

            val strength = remember(passwordInput) { SecurityCrypto.validatePasswordStrength(passwordInput) }
            if (passwordInput.isNotEmpty() && !strength.isStrong) {
                val missing = strength.checks.filter { !it.second }.joinToString(", ") { it.first }
                Text(
                    text = "Password requirements missing: $missing",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            OutlinedTextField(
                value = confirmPasswordInput,
                onValueChange = { confirmPasswordInput = it; formError = null },
                label = { Text("Confirm Password") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Confirm Password") },
                trailingIcon = {
                    IconButton(
                        onClick = { confirmPasswordVisible = !confirmPasswordVisible },
                        modifier = Modifier.testTag("reg_confirm_password_visibility_toggle")
                    ) {
                        Icon(
                            imageVector = if (confirmPasswordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = if (confirmPasswordVisible) "Hide Confirm Password" else "Show Confirm Password"
                        )
                    }
                },
                visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("reg_confirm_password_input")
            )

            // Role selection
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = selectedRole == PortalRole.TENANT,
                    onClick = { selectedRole = PortalRole.TENANT },
                    label = { Text("Tenant") },
                    modifier = Modifier.testTag("reg_role_tenant_chip")
                )
                FilterChip(
                    selected = selectedRole == PortalRole.OWNER,
                    onClick = { selectedRole = PortalRole.OWNER },
                    label = { Text("Property Owner") },
                    modifier = Modifier.testTag("reg_role_owner_chip")
                )
            }

            Button(
                onClick = {
                    val cleanName = fullName.trim()
                    val cleanEmail = emailInput.trim().lowercase()
                    val passCheck = SecurityCrypto.validatePasswordStrength(passwordInput)
                    when {
                        cleanName.length < 2 -> {
                            formError = "Enter your full name."
                            return@Button
                        }
                        !AuthManager.isValidEmail(cleanEmail) -> {
                            formError = "Enter a valid email address."
                            return@Button
                        }
                        !passCheck.isStrong -> {
                            val missing = passCheck.checks.filter { !it.second }.joinToString(", ") { it.first }
                            formError = "Password must include: $missing."
                            return@Button
                        }
                        passwordInput != confirmPasswordInput -> {
                            formError = "Passwords do not match."
                            return@Button
                        }
                    }
                    formError = null
                    formInfo = null
                    isCreatingAccount = true
                    scope.launch {
                        AuthManager.createAccountWithEmailPassword(
                            fullName = cleanName,
                            email = cleanEmail,
                            password = passwordInput
                        ).fold(
                            onSuccess = {
                                val db = FirebaseFirestore.getInstance(context.getString(R.string.firestore_database_id))
                                val repo = NestHavenRepository(db)
                                repo.registerEmailPasswordUserAccount(
                                    fullName = cleanName,
                                    email = cleanEmail,
                                    accountType = selectedRole,
                                    preferredLanguageCode = language.code
                                ).fold(
                                    onSuccess = {
                                        isCreatingAccount = false
                                        pendingVerificationEmail = cleanEmail
                                        resendCooldown = 60
                                        formInfo = "Verification email sent to $cleanEmail."
                                    },
                                    onFailure = { repoErr ->
                                        isCreatingAccount = false
                                        // Firebase Auth account was created; still prompt email verification if needed
                                        pendingVerificationEmail = cleanEmail
                                        resendCooldown = 60
                                        formError = repoErr.localizedMessage ?: "Account created; verify your email to continue."
                                    }
                                )
                            },
                            onFailure = { authErr ->
                                isCreatingAccount = false
                                formError = authErr.localizedMessage ?: "Account creation failed."
                            }
                        )
                    }
                },
                enabled = !isCreatingAccount,
                colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .minimumInteractiveComponentSize()
                    .testTag("create_account_button")
            ) {
                if (isCreatingAccount) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = ChampagneGoldSoft,
                        strokeWidth = 2.dp
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text(strings.createAccountLabel, fontWeight = FontWeight.Bold)
            }

            TextButton(
                onClick = onBackToLogin,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .testTag("back_to_login_button")
            ) {
                Text("Already have an account? Login")
            }
        }

        if (!formInfo.isNullOrBlank()) {
            Surface(
                color = ChampagneGoldSoft,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, ChampagneGold)
            ) {
                Text(
                    text = formInfo.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = DeepEmerald,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp)
                )
            }
        }

        if (!formError.isNullOrBlank()) {
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = formError.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp)
                )
            }
        }
    }
}
