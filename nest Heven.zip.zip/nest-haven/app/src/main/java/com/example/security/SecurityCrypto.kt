package com.example.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.nio.ByteBuffer
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

data class PasswordStrengthResult(
    val isStrong: Boolean,
    val score: Int,
    val checks: List<Pair<String, Boolean>>
)

object SecurityCrypto {
    private const val BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
    private const val KEY_ALIAS = "nest_haven_vault_aes256_key"
    private const val PREFS_NAME = "nest_haven_encrypted_vault"

    fun validatePasswordStrength(password: String): PasswordStrengthResult {
        val hasMinLength = password.length >= 12
        val hasUpper = password.any { it.isUpperCase() }
        val hasLower = password.any { it.isLowerCase() }
        val hasDigit = password.any { it.isDigit() }
        val hasSpecial = password.any { !it.isLetterOrDigit() }
        val checks = listOf(
            "12+ characters" to hasMinLength,
            "Uppercase letter (A-Z)" to hasUpper,
            "Lowercase letter (a-z)" to hasLower,
            "Numeric digit (0-9)" to hasDigit,
            "Special symbol (!@#\$%...)" to hasSpecial
        )
        val score = checks.count { it.second }
        return PasswordStrengthResult(
            isStrong = score == 5,
            score = score,
            checks = checks
        )
    }

    fun generateSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun hashPassphrase(passphrase: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val input = "$salt:$passphrase:nest_haven_v1".toByteArray(Charsets.UTF_8)
        val hashed = digest.digest(input)
        return hashed.joinToString("") { "%02x".format(it) }
    }

    fun verifyPassphrase(passphrase: String, salt: String, expectedHash: String): Boolean {
        if (salt.isBlank() || expectedHash.isBlank()) return false
        return MessageDigest.isEqual(
            hashPassphrase(passphrase, salt).toByteArray(Charsets.UTF_8),
            expectedHash.toByteArray(Charsets.UTF_8)
        )
    }

    fun sha256Hex(payload: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(payload.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    fun generateBase32Secret(length: Int = 16): String {
        val rng = SecureRandom()
        return buildString(length) {
            repeat(length) {
                append(BASE32_ALPHABET[rng.nextInt(BASE32_ALPHABET.length)])
            }
        }
    }

    fun generateRecoveryCodes(count: Int = 6): List<String> {
        val rng = SecureRandom()
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return List(count) {
            val part1 = (1..4).map { chars[rng.nextInt(chars.length)] }.joinToString("")
            val part2 = (1..4).map { chars[rng.nextInt(chars.length)] }.joinToString("")
            "NH-$part1-$part2"
        }
    }

    fun computeTotpCode(base32Secret: String, timeMillis: Long = System.currentTimeMillis()): String {
        val keyBytes = decodeBase32(base32Secret)
        if (keyBytes.isEmpty()) return "000000"
        val counter = (timeMillis / 1000L) / 30L
        val data = ByteBuffer.allocate(8).putLong(counter).array()
        val mac = Mac.getInstance("HmacSHA1")
        mac.init(SecretKeySpec(keyBytes, "HmacSHA1"))
        val hmac = mac.doFinal(data)
        val offset = hmac.last().toInt() and 0x0F
        val binary = ((hmac[offset].toInt() and 0x7F) shl 24) or
            ((hmac[offset + 1].toInt() and 0xFF) shl 16) or
            ((hmac[offset + 2].toInt() and 0xFF) shl 8) or
            (hmac[offset + 3].toInt() and 0xFF)
        val otp = binary % 1_000_000
        return "%06d".format(otp)
    }

    fun remainingTotpSeconds(timeMillis: Long = System.currentTimeMillis()): Int {
        val elapsed = ((timeMillis / 1000L) % 30L).toInt()
        return 30 - elapsed
    }

    fun verifyTotpCode(
        base32Secret: String,
        inputCode: String,
        timeMillis: Long = System.currentTimeMillis()
    ): Boolean {
        val trimmed = inputCode.trim()
        if (trimmed.length != 6 || !trimmed.all { it.isDigit() }) return false
        for (window in -1..1) {
            val candidate = computeTotpCode(base32Secret, timeMillis + window * 30_000L)
            if (candidate == trimmed) return true
        }
        return false
    }

    fun containsSensitiveSecretPattern(value: String): Boolean {
        val lower = value.lowercase()
        val blockedPrefixes = listOf(
            "sk_live_", "sk_test_", "rk_live_", "aiza", "ghp_", "xoxb-",
            "-----begin", "password=", "secret="
        )
        if (blockedPrefixes.any { lower.contains(it) }) return true
        // Reject raw 12-19 digit sequences that resemble raw bank accounts or card numbers
        val compactDigits = value.filter { it.isDigit() }
        return compactDigits.length >= 12
    }

    private fun decodeBase32(base32: String): ByteArray {
        val clean = base32.uppercase().filter { it in BASE32_ALPHABET }
        if (clean.isEmpty()) return ByteArray(0)
        val out = ArrayList<Byte>()
        var buffer = 0
        var bitsLeft = 0
        for (ch in clean) {
            val val5 = BASE32_ALPHABET.indexOf(ch)
            buffer = (buffer shl 5) or val5
            bitsLeft += 5
            if (bitsLeft >= 8) {
                bitsLeft -= 8
                out.add(((buffer shr bitsLeft) and 0xFF).toByte())
            }
        }
        return out.toByteArray()
    }

    // Android Keystore AES-256-GCM Encrypted Local Vault
    private fun getOrCreateAesKey(): SecretKey {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val existing = ks.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGen.init(spec)
        return keyGen.generateKey()
    }

    fun saveEncryptedSecret(context: Context, key: String, plaintext: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateAesKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        val encodedIv = Base64.encodeToString(iv, Base64.NO_WRAP)
        val encodedCipher = Base64.encodeToString(encrypted, Base64.NO_WRAP)
        context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(key, "$encodedIv:$encodedCipher")
            .apply()
    }

    fun loadEncryptedSecret(context: Context, key: String): String? {
        val stored = context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(key, null) ?: return null
        val parts = stored.split(":", limit = 2)
        if (parts.size != 2) return null
        return try {
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val ciphertext = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateAesKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }
}
