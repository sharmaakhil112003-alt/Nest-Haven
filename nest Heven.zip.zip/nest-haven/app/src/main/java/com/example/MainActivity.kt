package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.EventNote
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.firebase.AuthManager
import com.example.data.firebase.NestHavenRepository
import com.example.data.location.IndiaLocations
import com.example.data.model.PortalRole
import com.example.data.model.UiState
import com.example.data.model.UserSecurityProfile
import com.example.security.KeystoreVaultStore
import com.example.ui.components.RecoveryCodesDialog
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppLocalization
import com.example.ui.screens.AlertsAndSupportScreen
import com.example.ui.screens.LanguageTogglePill
import com.example.ui.screens.NestHavenHomeScreen
import com.example.ui.screens.NestHavenLoginRegisterScreen
import com.example.ui.screens.OwnerPendingVerificationGate
import com.example.ui.screens.OwnerPropertiesAndRequestsScreen
import com.example.ui.screens.OwnerRentPaymentsScreen
import com.example.ui.screens.ProfileAndReviewsScreen
import com.example.ui.screens.PublicTwoFactorUnlockScreen
import com.example.ui.screens.TenantBookingsAndPaymentsScreen
import com.example.ui.screens.TenantSearchScreen
import com.example.ui.theme.NestHavenTheme
import com.example.ui.viewmodel.MainViewModel
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

private enum class AppLaunchStage {
    LOGIN_REGISTER,
    PUBLIC_HOMEPAGE,
    PORTAL_DASHBOARD
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (FirebaseApp.getApps(this).isEmpty()) {
            FirebaseApp.initializeApp(this)
        }
        enableEdgeToEdge()
        setContent {
            NestHavenTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val currentUser by AuthManager.authStateFlow(auth)
        .collectAsStateWithLifecycle(initialValue = auth.currentUser)

    // Always open on the LOGIN / REGISTER screen first when app starts
    var launchStage by rememberSaveable { mutableStateOf(AppLaunchStage.LOGIN_REGISTER) }
    var selectedRole by rememberSaveable { mutableStateOf(PortalRole.TENANT) }
    var selectedLanguage by rememberSaveable { mutableStateOf(AppLanguage.ENGLISH) }
    var pendingRegName by rememberSaveable { mutableStateOf("") }
    var pendingRegPhone by rememberSaveable { mutableStateOf("") }

    val defaultState = IndiaLocations.allStatesAndUTs.first()
    val defaultCity = defaultState.cities.first()
    val defaultLocality = defaultCity.localities.first()
    var previewState by rememberSaveable { mutableStateOf(defaultState.name) }
    var previewCity by rememberSaveable { mutableStateOf(defaultCity.name) }
    var previewLocality by rememberSaveable { mutableStateOf(defaultLocality.name) }
    var previewRoomPref by rememberSaveable { mutableStateOf("ANY") }
    var previewBudgetInr by rememberSaveable { mutableLongStateOf(6000L) }

    val user = currentUser
    if ((launchStage == AppLaunchStage.PORTAL_DASHBOARD || launchStage == AppLaunchStage.PUBLIC_HOMEPAGE) &&
        (user == null || !user.isEmailVerified)
    ) {
        launchStage = AppLaunchStage.LOGIN_REGISTER
    }

    when (launchStage) {
        AppLaunchStage.LOGIN_REGISTER -> {
            val activeLabel = user?.let {
                it.email?.takeIf { e -> e.isNotBlank() }
                    ?: it.displayName?.takeIf { d -> d.isNotBlank() }
                    ?: "Registered User"
            }
            NestHavenLoginRegisterScreen(
                language = selectedLanguage,
                activeSessionLabel = activeLabel,
                isSessionEmailVerified = user?.isEmailVerified == true,
                onLanguageChange = { selectedLanguage = it },
                onContinueActiveSession = {
                    if (user != null && user.isEmailVerified) {
                        launchStage = AppLaunchStage.PUBLIC_HOMEPAGE
                    }
                },
                onSignOutActiveSession = {
                    pendingRegName = ""
                    pendingRegPhone = ""
                },
                onAuthSucceededToHomepage = { role, regName ->
                    if (role != null) selectedRole = role
                    pendingRegName = regName
                    pendingRegPhone = ""
                    launchStage = AppLaunchStage.PUBLIC_HOMEPAGE
                }
            )
        }

        AppLaunchStage.PUBLIC_HOMEPAGE -> {
            val sessionLabel = user?.let {
                it.email?.takeIf { e -> e.isNotBlank() }
                    ?: "Active Account"
            }
            NestHavenHomeScreen(
                selectedLanguage = selectedLanguage,
                signedInEmail = sessionLabel,
                previewState = previewState,
                previewCity = previewCity,
                previewLocality = previewLocality,
                previewRoomPreference = previewRoomPref,
                previewBudgetInr = previewBudgetInr,
                onLanguageChange = { selectedLanguage = it },
                onPreviewFiltersChange = { st, ct, loc, pref, budg ->
                    previewState = st
                    previewCity = ct
                    previewLocality = loc
                    previewRoomPref = pref
                    previewBudgetInr = budg
                },
                onFindRoomsClick = {
                    selectedRole = PortalRole.TENANT
                    launchStage = if (user != null && user.isEmailVerified) {
                        AppLaunchStage.PORTAL_DASHBOARD
                    } else {
                        AppLaunchStage.LOGIN_REGISTER
                    }
                },
                onOwnerLoginClick = {
                    selectedRole = PortalRole.OWNER
                    launchStage = if (user != null && user.isEmailVerified) {
                        AppLaunchStage.PORTAL_DASHBOARD
                    } else {
                        AppLaunchStage.LOGIN_REGISTER
                    }
                },
                onSignOutClick = {
                    AuthManager.signOut(credentialManager = credentialManager, scope = scope) {
                        pendingRegName = ""
                        pendingRegPhone = ""
                        launchStage = AppLaunchStage.LOGIN_REGISTER
                    }
                }
            )
        }

        AppLaunchStage.PORTAL_DASHBOARD -> {
            val activeUser = user ?: return
            key(activeUser.uid) {
                AuthenticatedPublicShell(
                    currentUserId = activeUser.uid,
                    initialRole = selectedRole,
                    initialLanguage = selectedLanguage,
                    initialRegName = pendingRegName,
                    initialRegPhone = pendingRegPhone,
                    initialSearchState = previewState,
                    initialSearchCity = previewCity,
                    initialSearchLocality = previewLocality,
                    initialRoomPreference = previewRoomPref,
                    initialBudgetInr = previewBudgetInr,
                    onLanguageSynced = { selectedLanguage = it },
                    onNavigateToHomepage = { launchStage = AppLaunchStage.PUBLIC_HOMEPAGE },
                    onSignedOut = {
                        pendingRegName = ""
                        pendingRegPhone = ""
                        launchStage = AppLaunchStage.LOGIN_REGISTER
                    }
                )
            }
        }
    }
}

@Composable
private fun AuthenticatedPublicShell(
    currentUserId: String,
    initialRole: PortalRole,
    initialLanguage: AppLanguage,
    initialRegName: String,
    initialRegPhone: String,
    initialSearchState: String,
    initialSearchCity: String,
    initialSearchLocality: String,
    initialRoomPreference: String,
    initialBudgetInr: Long,
    onLanguageSynced: (AppLanguage) -> Unit,
    onNavigateToHomepage: () -> Unit,
    onSignedOut: () -> Unit
) {
    BackHandler(onBack = onNavigateToHomepage)

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: MainViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                MainViewModel(
                    repository = NestHavenRepository(db),
                    vaultStore = KeystoreVaultStore(app),
                    currentUserId = currentUserId,
                    initialPortalRole = initialRole,
                    initialLanguage = initialLanguage,
                    initialRegistrationName = initialRegName,
                    initialRegistrationPhone = initialRegPhone
                )
            }
        }
    )

    LaunchedEffect(initialRole, initialLanguage, initialRegName, initialRegPhone) {
        viewModel.syncPortalEntry(
            role = initialRole,
            language = initialLanguage,
            regName = initialRegName,
            regPhone = initialRegPhone
        )
    }

    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val profileState by viewModel.userProfileState.collectAsStateWithLifecycle()
    val activeRole by viewModel.selectedPortalRole.collectAsStateWithLifecycle()
    val activeLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    val twoFactorUnlocked by viewModel.twoFactorUnlocked.collectAsStateWithLifecycle()
    val generatedRecoveryCodes by viewModel.generatedRecoveryCodes.collectAsStateWithLifecycle()
    val feedbackMessage by viewModel.feedbackMessage.collectAsStateWithLifecycle()

    LaunchedEffect(activeLanguage) {
        onLanguageSynced(activeLanguage)
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(feedbackMessage) {
        val msg = feedbackMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedback()
        }
    }

    val signOutAction: () -> Unit = {
        AuthManager.signOut(credentialManager = credentialManager, scope = scope) {
            onSignedOut()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { outerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(outerPadding)
        ) {
            when (val sState = sessionState) {
                is UiState.Loading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator()
                            Text(
                                text = "Loading Nest Haven...",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(top = 12.dp)
                            )
                        }
                    }
                }

                is UiState.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Unable to connect: ${sState.message}",
                                color = MaterialTheme.colorScheme.error
                            )
                            Button(
                                onClick = { viewModel.refreshSession() },
                                modifier = Modifier.padding(top = 12.dp)
                            ) {
                                Text("Retry")
                            }
                            Button(
                                onClick = onNavigateToHomepage,
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                Text("Back to Homepage")
                            }
                        }
                    }
                }

                is UiState.Success -> {
                    val session = sState.data
                    val liveProfile = (profileState as? UiState.Success)?.data ?: session.profile

                    if (liveProfile.totpEnabled && !twoFactorUnlocked) {
                        PublicTwoFactorUnlockScreen(
                            email = session.email,
                            profile = liveProfile,
                            onUnlock = { pass, code, prof -> viewModel.unlockWith2FA(pass, code, prof) },
                            onSignOut = signOutAction
                        )
                    } else {
                        PublicPortalWorkspace(
                            viewModel = viewModel,
                            activeRole = activeRole,
                            activeLanguage = activeLanguage,
                            profile = liveProfile,
                            initialSearchState = initialSearchState,
                            initialSearchCity = initialSearchCity,
                            initialSearchLocality = initialSearchLocality,
                            initialRoomPreference = initialRoomPreference,
                            initialBudgetInr = initialBudgetInr,
                            onNavigateToHomepage = onNavigateToHomepage,
                            onSignOut = signOutAction
                        )
                    }
                }
            }
        }
    }

    if (generatedRecoveryCodes.isNotEmpty()) {
        RecoveryCodesDialog(
            codes = generatedRecoveryCodes,
            onDismiss = { viewModel.dismissRecoveryCodes() }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PublicPortalWorkspace(
    viewModel: MainViewModel,
    activeRole: PortalRole,
    activeLanguage: AppLanguage,
    profile: UserSecurityProfile,
    initialSearchState: String,
    initialSearchCity: String,
    initialSearchLocality: String,
    initialRoomPreference: String,
    initialBudgetInr: Long,
    onNavigateToHomepage: () -> Unit,
    onSignOut: () -> Unit
) {
    val strings = AppLocalization.get(activeLanguage)
    var selectedTab by rememberSaveable(activeRole) { mutableIntStateOf(0) }
    val isExpandedScreen = LocalConfiguration.current.screenWidthDp >= 700

    val publishedPropertiesState by viewModel.publishedPropertiesState.collectAsStateWithLifecycle()
    val ownerPropertiesState by viewModel.ownerPropertiesState.collectAsStateWithLifecycle()
    val searchUnlocksState by viewModel.searchUnlocksState.collectAsStateWithLifecycle()
    val tenantBookingsState by viewModel.tenantBookingsState.collectAsStateWithLifecycle()
    val ownerBookingsState by viewModel.ownerBookingsState.collectAsStateWithLifecycle()
    val tenantOrdersState by viewModel.tenantPaymentOrdersState.collectAsStateWithLifecycle()
    val ownerOrdersState by viewModel.ownerPaymentOrdersState.collectAsStateWithLifecycle()
    val notificationsState by viewModel.notificationsState.collectAsStateWithLifecycle()
    val complaintsState by viewModel.complaintsState.collectAsStateWithLifecycle()
    val myReviewsState by viewModel.myReviewsState.collectAsStateWithLifecycle()
    val reviewsAboutMeState by viewModel.reviewsAboutMeState.collectAsStateWithLifecycle()
    val activeTotpSecret by viewModel.activeTotpSecret.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

    val publishedProperties = (publishedPropertiesState as? UiState.Success)?.data ?: emptyList()
    val ownerProperties = (ownerPropertiesState as? UiState.Success)?.data ?: emptyList()
    val searchUnlocks = (searchUnlocksState as? UiState.Success)?.data ?: emptyList()
    val tenantBookings = (tenantBookingsState as? UiState.Success)?.data ?: emptyList()
    val ownerBookings = (ownerBookingsState as? UiState.Success)?.data ?: emptyList()
    val tenantOrders = (tenantOrdersState as? UiState.Success)?.data ?: emptyList()
    val ownerOrders = (ownerOrdersState as? UiState.Success)?.data ?: emptyList()
    val notifications = (notificationsState as? UiState.Success)?.data ?: emptyList()
    val complaints = (complaintsState as? UiState.Success)?.data ?: emptyList()
    val myReviews = (myReviewsState as? UiState.Success)?.data ?: emptyList()
    val reviewsAboutMe = (reviewsAboutMeState as? UiState.Success)?.data ?: emptyList()

    val unreadCount = notifications.count { !it.readFlag }
    val isVerifiedOwner = profile.ownerApproved && profile.kycVerified

    val tabs = if (activeRole == PortalRole.TENANT) {
        listOf(
            Triple(strings.searchTab, Icons.Filled.Search, 0),
            Triple(strings.bookingsTab, Icons.AutoMirrored.Filled.EventNote, 1),
            Triple(strings.alertsTab, Icons.Filled.Notifications, 2),
            Triple(strings.profileTab, Icons.Filled.Person, 3)
        )
    } else {
        listOf(
            Triple("Properties", Icons.Filled.Apartment, 0),
            Triple("Payments", Icons.Filled.Payments, 1),
            Triple(strings.alertsTab, Icons.Filled.Notifications, 2),
            Triple(strings.profileTab, Icons.Filled.Person, 3)
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateToHomepage) {
                        Icon(Icons.Filled.Home, contentDescription = strings.backToHome)
                    }
                },
                title = {
                    Column {
                        Text(
                            text = if (activeRole == PortalRole.TENANT) "${strings.appName} • Tenant" else "${strings.appName} • Owner",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = strings.tagline,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                ),
                actions = {
                    LanguageTogglePill(
                        selectedLanguage = activeLanguage,
                        onLanguageChange = { viewModel.setLanguage(it) }
                    )
                    IconButton(onClick = onSignOut) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = strings.signOut)
                    }
                }
            )
        },
        bottomBar = {
            if (!isExpandedScreen) {
                NavigationBar {
                    tabs.forEach { (label, icon, index) ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = {
                                if (index == 2 && unreadCount > 0) {
                                    BadgedBox(badge = { Badge { Text(unreadCount.toString()) } }) {
                                        Icon(icon, contentDescription = label)
                                    }
                                } else {
                                    Icon(icon, contentDescription = label)
                                }
                            },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isExpandedScreen) {
                NavigationRail {
                    tabs.forEach { (label, icon, index) ->
                        NavigationRailItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = {
                                if (index == 2 && unreadCount > 0) {
                                    BadgedBox(badge = { Badge { Text(unreadCount.toString()) } }) {
                                        Icon(icon, contentDescription = label)
                                    }
                                } else {
                                    Icon(icon, contentDescription = label)
                                }
                            },
                            label = { Text(label) }
                        )
                    }
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                if (activeRole == PortalRole.TENANT) {
                    when (selectedTab) {
                        0 -> TenantSearchScreen(
                            language = activeLanguage,
                            publishedProperties = publishedProperties,
                            searchUnlocks = searchUnlocks,
                            paymentOrders = tenantOrders,
                            isBusy = isBusy,
                            initialState = initialSearchState,
                            initialCity = initialSearchCity,
                            initialLocality = initialSearchLocality,
                            initialRoomPreference = initialRoomPreference,
                            initialBudgetInr = initialBudgetInr,
                            onCreateSearch99Order = { st, ct, loc, bldg, budg, pref, facs, cb ->
                                viewModel.createSearchUnlockAnd99Order(st, ct, loc, bldg, budg, pref, facs, cb)
                            },
                            onMarkPaymentFailedOrCancelled = { id, st, rsn ->
                                viewModel.markPaymentOrderFailedOrCancelled(id, st, rsn)
                            },
                            onAcceptAlternative = { viewModel.acceptSearchAlternative(it) },
                            onRequestRefund = { viewModel.requestSearchRefund(it) },
                            onSubmitBookingOrVisit = { prop, type, dur ->
                                viewModel.createBookingOrVisitRequest(prop, type, dur)
                            },
                            onSwitchToBookingsTab = { selectedTab = 1 }
                        )

                        1 -> TenantBookingsAndPaymentsScreen(
                            language = activeLanguage,
                            bookings = tenantBookings,
                            paymentOrders = tenantOrders,
                            myReviews = myReviews,
                            onCancelBooking = { id, rsn -> viewModel.cancelTenantBooking(id, rsn) },
                            onCreateMonthlyRentOrder = { bkg, mo -> viewModel.createMonthlyRentOrder(bkg, mo) },
                            onMarkPaymentFailedOrCancelled = { id, st, rsn ->
                                viewModel.markPaymentOrderFailedOrCancelled(id, st, rsn)
                            },
                            onSubmitReview = { bkg, rat, cmt -> viewModel.submitStayReview(bkg, rat, cmt) }
                        )

                        2 -> AlertsAndSupportScreen(
                            language = activeLanguage,
                            notifications = notifications,
                            complaints = complaints,
                            isBusy = isBusy,
                            onMarkNotificationRead = { viewModel.markNotificationRead(it) },
                            onSubmitComplaint = { cat, sub, desc -> viewModel.submitComplaint(cat, sub, desc) }
                        )

                        else -> ProfileAndReviewsScreen(
                            language = activeLanguage,
                            activeRole = activeRole,
                            profile = profile,
                            totpSecret = activeTotpSecret,
                            reviewsAboutMe = reviewsAboutMe,
                            isBusy = isBusy,
                            onLanguageChange = { viewModel.setLanguage(it) },
                            onUpdateProfile = { name, phone, role, lang ->
                                viewModel.updateProfile(name, phone, role, lang)
                            },
                            onEnableOptional2FA = { pass, code -> viewModel.enableOptionalSecurity2FA(pass, code) },
                            onSignOut = onSignOut
                        )
                    }
                } else {
                    when (selectedTab) {
                        0 -> if (!isVerifiedOwner) {
                            OwnerPendingVerificationGate(
                                language = activeLanguage,
                                profile = profile,
                                onGoToProfile = { selectedTab = 3 },
                                onSwitchToTenant = { viewModel.switchPortalRole(PortalRole.TENANT) }
                            )
                        } else {
                            OwnerPropertiesAndRequestsScreen(
                                language = activeLanguage,
                                properties = ownerProperties,
                                bookings = ownerBookings,
                                myReviews = myReviews,
                                onDecision = { bkg, ok, note -> viewModel.submitOwnerBookingDecision(bkg, ok, note) },
                                onReviewTenant = { bkg, rat, cmt -> viewModel.submitStayReview(bkg, rat, cmt) }
                            )
                        }

                        1 -> if (!isVerifiedOwner) {
                            OwnerPendingVerificationGate(
                                language = activeLanguage,
                                profile = profile,
                                onGoToProfile = { selectedTab = 3 },
                                onSwitchToTenant = { viewModel.switchPortalRole(PortalRole.TENANT) }
                            )
                        } else {
                            OwnerRentPaymentsScreen(
                                language = activeLanguage,
                                orders = ownerOrders,
                                onAcknowledgeReceipt = { viewModel.acknowledgeVerifiedRentReceipt(it) }
                            )
                        }

                        2 -> AlertsAndSupportScreen(
                            language = activeLanguage,
                            notifications = notifications,
                            complaints = complaints,
                            isBusy = isBusy,
                            onMarkNotificationRead = { viewModel.markNotificationRead(it) },
                            onSubmitComplaint = { cat, sub, desc -> viewModel.submitComplaint(cat, sub, desc) }
                        )

                        else -> ProfileAndReviewsScreen(
                            language = activeLanguage,
                            activeRole = activeRole,
                            profile = profile,
                            totpSecret = activeTotpSecret,
                            reviewsAboutMe = reviewsAboutMe,
                            isBusy = isBusy,
                            onLanguageChange = { viewModel.setLanguage(it) },
                            onUpdateProfile = { name, phone, role, lang ->
                                viewModel.updateProfile(name, phone, role, lang)
                            },
                            onEnableOptional2FA = { pass, code -> viewModel.enableOptionalSecurity2FA(pass, code) },
                            onSignOut = onSignOut
                        )
                    }
                }
            }
        }
    }
}
