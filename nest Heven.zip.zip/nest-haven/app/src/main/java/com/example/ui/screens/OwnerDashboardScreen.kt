package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.BookingRequest
import com.example.data.model.PaymentOrder
import com.example.data.model.PropertyRecord
import com.example.data.model.StayReview
import com.example.data.model.UserSecurityProfile
import com.example.ui.components.EmptyVaultState
import com.example.ui.components.KpiMetricCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.SecurityStatusPill
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppLocalization
import com.example.ui.i18n.formatInr
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.AmberWarningContainer
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneGoldSoft
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepEmerald
import com.example.ui.theme.MonoTextStyle
import com.example.ui.theme.VerifiedJade
import com.example.ui.theme.VerifiedJadeContainer

@Composable
fun OwnerPendingVerificationGate(
    language: AppLanguage,
    profile: UserSecurityProfile,
    onGoToProfile: () -> Unit,
    onSwitchToTenant: () -> Unit
) {
    val strings = AppLocalization.get(language)
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 520.dp)
                .testTag("owner_pending_gate_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.5.dp, ChampagneGold)
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.HourglassTop,
                        contentDescription = strings.ownerPendingTitle,
                        tint = AmberWarning,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = strings.ownerPendingTitle,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Text(
                    text = strings.ownerPendingMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Surface(
                    color = AmberWarningContainer,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "Approval Status: ownerApproved=${profile.ownerApproved} • kycVerified=${profile.kycVerified}",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = AmberWarning
                        )
                        Text(
                            text = strings.ownerNoPublishNotice,
                            style = MaterialTheme.typography.bodySmall,
                            color = AmberWarning
                        )
                    }
                }
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Your Owner UID", style = MaterialTheme.typography.labelSmall)
                            Text(profile.userId, style = MonoTextStyle)
                        }
                        IconButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(profile.userId))
                                copied = true
                            }
                        ) {
                            Icon(Icons.Filled.ContentCopy, contentDescription = "Copy Owner UID")
                        }
                    }
                }
                if (copied) {
                    Text(
                        "UID copied to clipboard.",
                        style = MaterialTheme.typography.labelSmall,
                        color = VerifiedJade
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onGoToProfile,
                        colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Open Profile & Support")
                    }
                    OutlinedButton(
                        onClick = onSwitchToTenant,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Switch to Tenant")
                    }
                }
            }
        }
    }
}

@Composable
fun OwnerPropertiesAndRequestsScreen(
    language: AppLanguage,
    properties: List<PropertyRecord>,
    bookings: List<BookingRequest>,
    myReviews: List<StayReview>,
    onDecision: (BookingRequest, Boolean, String) -> Unit,
    onReviewTenant: (BookingRequest, Long, String) -> Unit
) {
    val strings = AppLocalization.get(language)
    var decisionTarget by remember { mutableStateOf<Pair<BookingRequest, Boolean>?>(null) }
    var bookingToReview by remember { mutableStateOf<BookingRequest?>(null) }
    val reviewedIds = remember(myReviews) { myReviews.map { it.bookingId }.toSet() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(
                    modifier = Modifier.widthIn(max = 760.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SectionHeader(
                        title = "Verified Owner Properties & Requests",
                        subtitle = "Manage assigned listings & review tenant booking/visit requests"
                    )
                    Surface(
                        color = ChampagneGoldSoft,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, ChampagneGold)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Lock, contentDescription = null, tint = DeepEmerald, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = strings.ownerNoPublishNotice,
                                style = MaterialTheme.typography.bodySmall,
                                color = DeepEmerald
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        KpiMetricCard(
                            title = "Assigned Rooms",
                            value = properties.size.toString(),
                            subtitle = "Admin-published",
                            icon = Icons.Filled.Apartment,
                            modifier = Modifier.weight(1f)
                        )
                        KpiMetricCard(
                            title = "Tenant Requests",
                            value = bookings.count { it.ownerDecision == "PENDING" }.toString(),
                            subtitle = "Awaiting decision",
                            icon = Icons.Filled.VerifiedUser,
                            accentColor = ChampagneGold,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Assigned Properties (Strictly Read-Only)
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                SectionHeader(
                    title = "Assigned Properties & Availability",
                    modifier = Modifier.widthIn(max = 760.dp)
                )
            }
        }
        if (properties.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    EmptyVaultState(
                        icon = Icons.Filled.Apartment,
                        title = "No Properties Assigned Yet",
                        message = "Only the separate Nest Haven Admin Portal can assign, verify, and publish properties/rooms under your owner UID.",
                        modifier = Modifier.widthIn(max = 760.dp)
                    )
                }
            }
        } else {
            items(properties, key = { it.id }) { prop ->
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 760.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "${prop.name} • Room ${prop.roomNumber}",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                SecurityStatusPill(
                                    label = prop.occupancyStatus,
                                    isPositive = prop.occupancyStatus == "AVAILABLE"
                                )
                            }
                            Text(
                                "${prop.locality}, ${prop.city}, ${prop.state} • ${prop.roomType} • ${formatInr(prop.monthlyRentInr)}/mo",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Tenant Booking & Visit Requests
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                SectionHeader(
                    title = "Tenant Booking & Visit Requests",
                    modifier = Modifier.widthIn(max = 760.dp)
                )
            }
        }
        if (bookings.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    EmptyVaultState(
                        icon = Icons.Filled.Info,
                        title = "No Tenant Requests Yet",
                        message = "Incoming visit schedules and rental booking requests appear here.",
                        modifier = Modifier.widthIn(max = 760.dp)
                    )
                }
            }
        } else {
            items(bookings, key = { it.id }) { booking ->
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 760.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "${booking.tenantName} • ${booking.requestType}",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        "${booking.propertyTitle} (${booking.durationMonths} mo • ${formatInr(booking.monthlyRentInr)}/mo)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                SecurityStatusPill(
                                    label = booking.ownerDecision,
                                    isPositive = booking.ownerDecision == "APPROVED"
                                )
                            }
                            if (booking.requestType == "BOOKING" && !booking.firstMonthRentPaid) {
                                Text(
                                    text = "Awaiting server verification of 1st-month rent before booking approval is allowed.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AmberWarning
                                )
                            }
                            if (booking.ownerDecision == "PENDING") {
                                val canApprove = booking.requestType == "VISIT" || booking.firstMonthRentPaid
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { decisionTarget = booking to true },
                                        enabled = canApprove,
                                        colors = ButtonDefaults.buttonColors(containerColor = VerifiedJade)
                                    ) {
                                        Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Accept")
                                    }
                                    OutlinedButton(
                                        onClick = { decisionTarget = booking to false },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonAlert)
                                    ) {
                                        Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Reject")
                                    }
                                }
                            } else if (booking.status == "COMPLETED" && booking.id !in reviewedIds) {
                                Button(
                                    onClick = { bookingToReview = booking },
                                    colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold)
                                ) {
                                    Icon(Icons.Filled.Star, contentDescription = null, tint = DeepEmerald, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Rate Tenant", color = DeepEmerald)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    decisionTarget?.let { (booking, approved) ->
        var note by rememberSaveable { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { decisionTarget = null },
            title = { Text(if (approved) "Approve Request" else "Reject Request") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${booking.tenantName} • ${booking.propertyTitle}")
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Decision Note (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDecision(booking, approved, note)
                        decisionTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (approved) VerifiedJade else CrimsonAlert
                    )
                ) {
                    Text(if (approved) "Confirm Approve" else "Confirm Reject")
                }
            },
            dismissButton = {
                TextButton(onClick = { decisionTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    bookingToReview?.let { booking ->
        StayReviewDialog(
            title = "Rate Verified Tenant (${booking.tenantName})",
            onDismiss = { bookingToReview = null },
            onSubmit = { rating, comment ->
                onReviewTenant(booking, rating, comment)
                bookingToReview = null
            }
        )
    }
}

@Composable
fun OwnerRentPaymentsScreen(
    language: AppLanguage,
    orders: List<PaymentOrder>,
    onAcknowledgeReceipt: (PaymentOrder) -> Unit
) {
    val strings = AppLocalization.get(language)
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(
                    modifier = Modifier.widthIn(max = 760.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SectionHeader(
                        title = "Rent Verification & 24h Settlement",
                        subtitle = "Verify server-confirmed tenant rent receipts & track payouts"
                    )
                    Surface(
                        color = VerifiedJadeContainer,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Payments, contentDescription = null, tint = VerifiedJade, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = strings.settlement24hNotice,
                                style = MaterialTheme.typography.bodySmall,
                                color = DeepEmerald
                            )
                        }
                    }
                }
            }
        }

        if (orders.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    EmptyVaultState(
                        icon = Icons.Filled.Payments,
                        title = "No Rent Orders Yet",
                        message = "Tenant rent payments and 24-hour settlement statuses will appear here.",
                        modifier = Modifier.widthIn(max = 760.dp)
                    )
                }
            }
        } else {
            items(orders, key = { it.id }) { order ->
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 760.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "${order.paymentPurpose.replace("_", " ")} • ${formatInr(order.amountInr)}",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                SecurityStatusPill(
                                    label = order.settlementStatus,
                                    isPositive = order.settlementStatus == "SETTLED_24H"
                                )
                            }
                            Text(
                                "Receipt: ${order.receiptRef} • Gateway Status: ${order.paymentStatus}",
                                style = MonoTextStyle,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (order.paymentStatus == "VERIFIED_BY_SERVER" && !order.ownerVerifiedReceipt) {
                                Button(
                                    onClick = { onAcknowledgeReceipt(order) },
                                    colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald)
                                ) {
                                    Text("Acknowledge Verified Rent Receipt")
                                }
                            } else if (order.ownerVerifiedReceipt) {
                                SecurityStatusPill(label = "Receipt Acknowledged by Owner", isPositive = true)
                            }
                        }
                    }
                }
            }
        }
    }
}
