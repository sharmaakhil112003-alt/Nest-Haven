package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = DeepEmerald,
    onPrimary = Color.White,
    primaryContainer = SageMist,
    onPrimaryContainer = DeepEmerald,
    secondary = ChampagneGold,
    onSecondary = SlateCharcoal,
    secondaryContainer = ChampagneGoldSoft,
    onSecondaryContainer = SlateCharcoal,
    tertiary = VerifiedJade,
    onTertiary = Color.White,
    tertiaryContainer = VerifiedJadeContainer,
    onTertiaryContainer = DeepEmerald,
    background = WarmIvory,
    onBackground = SlateCharcoal,
    surface = SoftAlabaster,
    onSurface = SlateCharcoal,
    surfaceVariant = SageMist,
    onSurfaceVariant = MutedPineText,
    outline = Color(0xFFC5D0CA),
    error = CrimsonAlert,
    onError = Color.White,
    errorContainer = CrimsonAlertContainer,
    onErrorContainer = CrimsonAlert
)

private val DarkColorScheme = darkColorScheme(
    primary = ChampagneGold,
    onPrimary = ObsidianVault,
    primaryContainer = DeepEmeraldLight,
    onPrimaryContainer = ChampagneGoldSoft,
    secondary = Color(0xFF4EC59A),
    onSecondary = ObsidianVault,
    secondaryContainer = ObsidianElevated,
    onSecondaryContainer = IvoryOnDark,
    tertiary = Color(0xFF69DFB6),
    onTertiary = ObsidianVault,
    tertiaryContainer = DeepEmerald,
    onTertiaryContainer = VerifiedJadeContainer,
    background = ObsidianVault,
    onBackground = IvoryOnDark,
    surface = ObsidianCard,
    onSurface = IvoryOnDark,
    surfaceVariant = ObsidianElevated,
    onSurfaceVariant = MutedSageOnDark,
    outline = Color(0xFF2B463C),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6)
)

private val NestHavenShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun NestHavenTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = NestHavenTypography,
        shapes = NestHavenShapes,
        content = content
    )
}
