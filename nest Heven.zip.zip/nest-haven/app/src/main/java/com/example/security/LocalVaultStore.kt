package com.example.security

import android.content.Context

interface LocalVaultStore {
    fun getOrCreateTotpSecret(uid: String): String
    fun rotateTotpSecret(uid: String): String
    fun saveRecoveryCodeHashes(uid: String, hashes: List<String>)
    fun consumeRecoveryCode(uid: String, rawCode: String): Boolean
    fun getRemainingRecoveryCodeCount(uid: String): Int
}

class KeystoreVaultStore(context: Context) : LocalVaultStore {
    private val appContext = context.applicationContext

    override fun getOrCreateTotpSecret(uid: String): String {
        val key = "totp_secret_$uid"
        val existing = SecurityCrypto.loadEncryptedSecret(appContext, key)
        if (!existing.isNullOrBlank()) return existing
        val created = SecurityCrypto.generateBase32Secret(16)
        SecurityCrypto.saveEncryptedSecret(appContext, key, created)
        return created
    }

    override fun rotateTotpSecret(uid: String): String {
        val key = "totp_secret_$uid"
        val created = SecurityCrypto.generateBase32Secret(16)
        SecurityCrypto.saveEncryptedSecret(appContext, key, created)
        return created
    }

    override fun saveRecoveryCodeHashes(uid: String, hashes: List<String>) {
        SecurityCrypto.saveEncryptedSecret(
            appContext,
            "recovery_hashes_$uid",
            hashes.joinToString(",")
        )
    }

    override fun consumeRecoveryCode(uid: String, rawCode: String): Boolean {
        val normalized = rawCode.trim().uppercase()
        val inputHash = SecurityCrypto.sha256Hex(normalized)
        val stored = SecurityCrypto.loadEncryptedSecret(appContext, "recovery_hashes_$uid")
            ?.split(",")
            ?.filter { it.isNotBlank() }
            ?: emptyList()
        if (inputHash !in stored) return false
        val remaining = stored.filterNot { it == inputHash }
        saveRecoveryCodeHashes(uid, remaining)
        return true
    }

    override fun getRemainingRecoveryCodeCount(uid: String): Int {
        return SecurityCrypto.loadEncryptedSecret(appContext, "recovery_hashes_$uid")
            ?.split(",")
            ?.count { it.isNotBlank() }
            ?: 0
    }
}
