package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.HomeWork
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.location.IndiaLocations
import com.example.data.model.PaymentOrder
import com.example.data.model.PropertyRecord
import com.example.data.model.SearchUnlock
import com.example.ui.components.EmptyVaultState
import com.example.ui.components.SectionHeader
import com.example.ui.components.SecurityStatusPill
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppLocalization
import com.example.ui.i18n.formatInr
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.AmberWarningContainer
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneGoldSoft
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepEmerald
import com.example.ui.theme.MonoTextStyle
import com.example.ui.theme.VerifiedJade
import com.example.ui.theme.VerifiedJadeContainer

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TenantSearchScreen(
    language: AppLanguage,
    publishedProperties: List<PropertyRecord>,
    searchUnlocks: List<SearchUnlock>,
    paymentOrders: List<PaymentOrder>,
    isBusy: Boolean,
    initialState: String = IndiaLocations.allStatesAndUTs.first().name,
    initialCity: String = IndiaLocations.allStatesAndUTs.first().cities.first().name,
    initialLocality: String = IndiaLocations.allStatesAndUTs.first().cities.first().localities.first().name,
    initialRoomPreference: String = "ANY",
    initialBudgetInr: Long = 6000L,
    onCreateSearch99Order: (
        state: String,
        city: String,
        locality: String,
        buildingFilter: String,
        monthlyBudgetInr: Long,
        roomPreference: String,
        requiredFacilities: List<String>,
        onCreated: (String, String) -> Unit
    ) -> Unit,
    onMarkPaymentFailedOrCancelled: (orderId: String, status: String, reason: String) -> Unit,
    onAcceptAlternative: (unlockId: String) -> Unit,
    onRequestRefund: (unlockId: String) -> Unit,
    onSubmitBookingOrVisit: (PropertyRecord, String, Long) -> Unit,
    onSwitchToBookingsTab: () -> Unit
) {
    val strings = AppLocalization.get(language)
    val statesList = IndiaLocations.allStatesAndUTs

    var selectedStateName by rememberSaveable(initialState) { mutableStateOf(initialState) }
    val selectedStateCatalog = remember(selectedStateName) {
        statesList.firstOrNull { it.name == selectedStateName } ?: statesList.first()
    }

    var selectedCityName by rememberSaveable(initialCity) { mutableStateOf(initialCity) }
    val selectedCityCatalog = remember(selectedStateCatalog, selectedCityName) {
        selectedStateCatalog.cities.firstOrNull { it.name == selectedCityName } ?: selectedStateCatalog.cities.first()
    }

    var selectedLocalityName by rememberSaveable(initialLocality) { mutableStateOf(initialLocality) }
    val selectedLocalityCatalog = remember(selectedCityCatalog, selectedLocalityName) {
        selectedCityCatalog.localities.firstOrNull { it.name == selectedLocalityName } ?: selectedCityCatalog.localities.first()
    }

    var buildingInput by rememberSaveable { mutableStateOf("") }
    var budgetSlider by rememberSaveable(initialBudgetInr) { mutableFloatStateOf(initialBudgetInr.toFloat().coerceIn(2000f, 50000f)) }
    var roomPreference by rememberSaveable(initialRoomPreference) { mutableStateOf(initialRoomPreference) }
    val selectedFacilities = remember { mutableStateListOf<String>() }

    var activeGatewayOrder by remember { mutableStateOf<PaymentOrder?>(null) }
    var selectedPropertyForDetail by remember { mutableStateOf<PropertyRecord?>(null) }

    val matchingProperties by remember(
        publishedProperties,
        selectedStateCatalog,
        selectedCityCatalog,
        selectedLocalityCatalog,
        buildingInput,
        budgetSlider,
        roomPreference,
        selectedFacilities.size
    ) {
        derivedStateOf {
            publishedProperties.filter { prop ->
                prop.published &&
                    prop.state.equals(selectedStateCatalog.name, ignoreCase = true) &&
                    prop.city.equals(selectedCityCatalog.name, ignoreCase = true) &&
                    prop.locality.equals(selectedLocalityCatalog.name, ignoreCase = true) &&
                    (buildingInput.isBlank() || prop.buildingName.contains(buildingInput.trim(), ignoreCase = true)) &&
                    prop.monthlyRentInr <= budgetSlider.toLong() &&
                    (roomPreference == "ANY" || prop.roomType.equals(roomPreference, ignoreCase = true)) &&
                    selectedFacilities.all { req -> prop.facilities.any { it.equals(req, ignoreCase = true) } }
            }
        }
    }

    val latestUnlockForLocality = remember(searchUnlocks, selectedCityCatalog, selectedLocalityCatalog) {
        searchUnlocks.firstOrNull {
            it.city.equals(selectedCityCatalog.name, ignoreCase = true) &&
                it.locality.equals(selectedLocalityCatalog.name, ignoreCase = true)
        }
    }

    val isLocalityUnlocked = latestUnlockForLocality?.unlockStatus == "UNLOCKED"

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(modifier = Modifier.widthIn(max = 760.dp)) {
                    SectionHeader(
                        title = strings.searchTitle,
                        subtitle = strings.searchSubtitle
                    )
                }
            }
        }

        // All-India Cascading Location + Budget + Preference Card
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Card(
                    modifier = Modifier.widthIn(max = 760.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.55f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CascadingLocationDropdown(
                            label = strings.selectState,
                            selected = selectedStateCatalog.name,
                            options = statesList.map { it.name },
                            icon = Icons.Filled.LocationOn,
                            testTag = "state_dropdown",
                            onSelect = { newState ->
                                selectedStateName = newState
                                val st = statesList.first { it.name == newState }
                                selectedCityName = st.cities.first().name
                                selectedLocalityName = st.cities.first().localities.first().name
                                buildingInput = ""
                            }
                        )

                        CascadingLocationDropdown(
                            label = strings.selectCity,
                            selected = selectedCityCatalog.name,
                            options = selectedStateCatalog.cities.map { it.name },
                            icon = Icons.Filled.LocationCity,
                            testTag = "city_dropdown",
                            onSelect = { newCity ->
                                selectedCityName = newCity
                                val city = selectedStateCatalog.cities.first { it.name == newCity }
                                selectedLocalityName = city.localities.first().name
                                buildingInput = ""
                            }
                        )

                        CascadingLocationDropdown(
                            label = strings.selectLocality,
                            selected = selectedLocalityCatalog.name,
                            options = selectedCityCatalog.localities.map { it.name },
                            icon = Icons.Filled.HomeWork,
                            testTag = "locality_dropdown",
                            onSelect = { newLoc ->
                                selectedLocalityName = newLoc
                                buildingInput = ""
                            }
                        )

                        if (selectedLocalityCatalog.buildings.isNotEmpty()) {
                            Text(
                                text = strings.selectBuildingOptional,
                                style = MaterialTheme.typography.labelLarge
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                FilterChip(
                                    selected = buildingInput.isBlank(),
                                    onClick = { buildingInput = "" },
                                    label = { Text("All Buildings") }
                                )
                                selectedLocalityCatalog.buildings.forEach { bldg ->
                                    FilterChip(
                                        selected = buildingInput == bldg,
                                        onClick = { buildingInput = if (buildingInput == bldg) "" else bldg },
                                        label = { Text(bldg) }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = buildingInput,
                            onValueChange = { buildingInput = it },
                            label = { Text(strings.selectBuildingOptional) },
                            leadingIcon = { Icon(Icons.Filled.Apartment, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        HorizontalDivider()

                        // Monthly Budget Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = strings.monthlyBudgetInr,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Surface(
                                color = ChampagneGoldSoft,
                                shape = RoundedCornerShape(999.dp)
                            ) {
                                Text(
                                    text = "${formatInr(budgetSlider.toLong())} / mo",
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                    color = DeepEmerald,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                )
                            }
                        }
                        Slider(
                            value = budgetSlider,
                            onValueChange = { budgetSlider = ((it / 500f).toInt() * 500).coerceIn(2000, 50000).toFloat() },
                            valueRange = 2000f..50000f,
                            colors = SliderDefaults.colors(
                                thumbColor = DeepEmerald,
                                activeTrackColor = ChampagneGold
                            ),
                            modifier = Modifier.testTag("budget_slider")
                        )

                        // Single / Double / Any Preference
                        Text(
                            text = strings.roomPreference,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("ANY" to "Single or Double", "SINGLE" to "Single Room", "DOUBLE" to "Double Room")
                                .forEach { (code, label) ->
                                    FilterChip(
                                        selected = roomPreference == code,
                                        onClick = { roomPreference = code },
                                        label = { Text(label) },
                                        leadingIcon = if (roomPreference == code) {
                                            { Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                        } else null
                                    )
                                }
                        }

                        // Required Facilities
                        Text(
                            text = strings.requiredFacilities,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            IndiaLocations.standardFacilities.forEach { facility ->
                                val selected = facility in selectedFacilities
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        if (selected) selectedFacilities.remove(facility)
                                        else selectedFacilities.add(facility)
                                    },
                                    label = { Text(facility) }
                                )
                            }
                        }

                        Spacer(Modifier.height(4.dp))

                        Button(
                            onClick = {
                                onCreateSearch99Order(
                                    selectedStateCatalog.name,
                                    selectedCityCatalog.name,
                                    selectedLocalityCatalog.name,
                                    buildingInput,
                                    budgetSlider.toLong(),
                                    roomPreference,
                                    selectedFacilities.toList()
                                ) { _, orderId ->
                                    val foundOrder = paymentOrders.firstOrNull { it.id == orderId }
                                        ?: PaymentOrder(
                                            id = orderId,
                                            paymentPurpose = "SEARCH_FEE_99",
                                            amountInr = 99L,
                                            paymentStatus = "AWAITING_GATEWAY_VERIFICATION",
                                            receiptRef = "NH99-${orderId.takeLast(8).uppercase()}"
                                        )
                                    activeGatewayOrder = foundOrder
                                }
                            },
                            enabled = !isBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("pay_99_unlock_button")
                        ) {
                            Icon(Icons.Filled.LockOpen, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(strings.pay99UnlockBtn)
                        }

                        Text(
                            text = "Refund Policy: If no matching room or suitable alternative is available after verification, your ₹99 search fee is eligible for refund. Accepted alternative rooms make ₹99 non-refundable.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Active Search Unlocks & Refund Verification Section
        if (searchUnlocks.isNotEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(
                        modifier = Modifier.widthIn(max = 760.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SectionHeader(
                            title = "Your ₹99 Locality Search Unlocks & Refunds",
                            subtitle = "Track gateway verification, offered alternatives, and refund claims"
                        )
                        searchUnlocks.forEach { unlock ->
                            val matchingOrder = paymentOrders.firstOrNull { it.id == unlock.paymentOrderId }
                            SearchUnlockStatusCard(
                                unlock = unlock,
                                order = matchingOrder,
                                onOpenGatewayCheckout = {
                                    if (matchingOrder != null) activeGatewayOrder = matchingOrder
                                },
                                onAcceptAlternative = { onAcceptAlternative(unlock.id) },
                                onRequestRefund = { onRequestRefund(unlock.id) }
                            )
                        }
                    }
                }
            }
        }

        // Verified Published Room Listings (Starts strictly empty with ZERO fake data)
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(modifier = Modifier.widthIn(max = 760.dp)) {
                    SectionHeader(
                        title = "Verified Rooms in ${selectedLocalityCatalog.name}, ${selectedCityCatalog.name}",
                        subtitle = if (publishedProperties.isEmpty()) {
                            "0 published listings in live database"
                        } else if (!isLocalityUnlocked) {
                            "${matchingProperties.size} matching listing(s) found — complete ₹99 unlock verification to inspect & book"
                        } else {
                            "${matchingProperties.size} unlocked verified listing(s)"
                        }
                    )
                }
            }
        }

        if (publishedProperties.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    EmptyVaultState(
                        icon = Icons.Filled.Apartment,
                        title = strings.emptyDatabaseTitle,
                        message = strings.emptyDatabaseMessage,
                        modifier = Modifier.widthIn(max = 760.dp)
                    )
                }
            }
        } else if (matchingProperties.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    EmptyVaultState(
                        icon = Icons.Filled.Info,
                        title = strings.noMatchingRoomsTitle,
                        message = strings.noMatchingRoomsMessage,
                        modifier = Modifier.widthIn(max = 760.dp)
                    )
                }
            }
        } else {
            items(matchingProperties, key = { it.id }) { prop ->
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    PropertySearchResultCard(
                        property = prop,
                        isUnlocked = isLocalityUnlocked,
                        modifier = Modifier.widthIn(max = 760.dp),
                        onClick = {
                            if (isLocalityUnlocked) {
                                selectedPropertyForDetail = prop
                            } else {
                                val existingOrder = paymentOrders.firstOrNull {
                                    it.searchUnlockId == latestUnlockForLocality?.id
                                }
                                if (existingOrder != null) {
                                    activeGatewayOrder = existingOrder
                                }
                            }
                        }
                    )
                }
            }
        }
    }

    activeGatewayOrder?.let { order ->
        PaymentOrderCheckoutDialog(
            order = order,
            onDismiss = { activeGatewayOrder = null },
            onMarkFailedOrCancelled = { status, reason ->
                onMarkPaymentFailedOrCancelled(order.id, status, reason)
                activeGatewayOrder = null
            }
        )
    }

    selectedPropertyForDetail?.let { prop ->
        PropertyDetailAndBookingDialog(
            property = prop,
            language = language,
            onDismiss = { selectedPropertyForDetail = null },
            onRequestVisit = { duration ->
                onSubmitBookingOrVisit(prop, "VISIT", duration)
                selectedPropertyForDetail = null
                onSwitchToBookingsTab()
            },
            onRequestBooking = { duration ->
                onSubmitBookingOrVisit(prop, "BOOKING", duration)
                selectedPropertyForDetail = null
                onSwitchToBookingsTab()
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CascadingLocationDropdown(
    label: String,
    selected: String,
    options: List<String>,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    testTag: String,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = Modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            leadingIcon = { Icon(icon, contentDescription = null) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                .fillMaxWidth()
                .testTag(testTag)
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onSelect(option)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun SearchUnlockStatusCard(
    unlock: SearchUnlock,
    order: PaymentOrder?,
    onOpenGatewayCheckout: () -> Unit,
    onAcceptAlternative: () -> Unit,
    onRequestRefund: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${unlock.locality}, ${unlock.city} (${unlock.state})",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Budget ${formatInr(unlock.monthlyBudgetInr)}/mo • Room: ${unlock.roomPreference}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                SecurityStatusPill(
                    label = unlock.unlockStatus,
                    isPositive = unlock.unlockStatus == "UNLOCKED"
                )
            }

            if (order != null) {
                Text(
                    text = "Order ${order.receiptRef} • Payment: ${order.paymentStatus}",
                    style = MonoTextStyle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (unlock.alternativeOffered && !unlock.alternativeAccepted) {
                Surface(
                    color = AmberWarningContainer,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Alternative Offered: ${formatInr(unlock.alternativeRentInr)}/month",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = AmberWarning
                        )
                        Text(
                            text = "If you accept this alternative, the ₹99 search fee becomes non-refundable.",
                            style = MaterialTheme.typography.bodySmall,
                            color = AmberWarning
                        )
                        Button(
                            onClick = onAcceptAlternative,
                            colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald)
                        ) {
                            Text("Accept Alternative Room")
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (order != null && order.paymentStatus == "AWAITING_GATEWAY_VERIFICATION") {
                    OutlinedButton(onClick = onOpenGatewayCheckout) {
                        Icon(Icons.Filled.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Gateway Checkout")
                    }
                }
                if (unlock.unlockStatus == "NO_MATCH_REFUND_ELIGIBLE" &&
                    !unlock.alternativeAccepted &&
                    unlock.refundStatus == "NONE"
                ) {
                    Button(
                        onClick = onRequestRefund,
                        colors = ButtonDefaults.buttonColors(containerColor = AmberWarning)
                    ) {
                        Text("Request ₹99 Refund Verification")
                    }
                } else if (unlock.refundStatus != "NONE") {
                    SecurityStatusPill(
                        label = "Refund: ${unlock.refundStatus}",
                        isPositive = unlock.refundStatus == "REFUNDED"
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PropertySearchResultCard(
    property: PropertyRecord,
    isUnlocked: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (isUnlocked && property.photoUrls.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(property.photoUrls) { url ->
                        AsyncImage(
                            model = url,
                            contentDescription = "Property photograph of ${property.name}",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(width = 210.dp, height = 132.dp)
                                .clip(RoundedCornerShape(14.dp))
                        )
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isUnlocked) property.name else "${property.locality} Verified Room (₹99 Unlock Required)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${property.locality}, ${property.city}, ${property.state}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(color = ChampagneGoldSoft, shape = RoundedCornerShape(999.dp)) {
                    Text(
                        text = "${formatInr(property.monthlyRentInr)}/mo",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = DeepEmerald,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SecurityStatusPill(
                    label = property.roomType,
                    isPositive = true
                )
                SecurityStatusPill(
                    label = property.occupancyStatus,
                    isPositive = property.occupancyStatus == "AVAILABLE"
                )
            }
            if (isUnlocked && property.facilities.isNotEmpty()) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    property.facilities.take(5).forEach { fac ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = fac,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
            Text(
                text = if (isUnlocked) "Tap to inspect owner details, book (2/6/12/24 mo) or schedule visit"
                else "Complete ₹99 locality unlock verification to inspect full room details & photos",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PropertyDetailAndBookingDialog(
    property: PropertyRecord,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onRequestVisit: (Long) -> Unit,
    onRequestBooking: (Long) -> Unit
) {
    val strings = AppLocalization.get(language)
    var selectedDuration by remember { mutableLongStateOf(6L) }
    val durations = listOf(2L, 6L, 12L, 24L)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("${property.name} • Room ${property.roomNumber}")
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (property.photoUrls.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(property.photoUrls) { url ->
                            AsyncImage(
                                model = url,
                                contentDescription = "Verified property photo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(width = 200.dp, height = 120.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            )
                        }
                    }
                }
                Text(
                    text = "${property.buildingName.ifBlank { "Building" }} • ${property.address}",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    text = "${property.locality}, ${property.city}, ${property.state}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Surface(color = VerifiedJadeContainer, shape = RoundedCornerShape(10.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Monthly Rent (${property.roomType})", style = MaterialTheme.typography.labelMedium)
                        Text(
                            formatInr(property.monthlyRentInr),
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = DeepEmerald
                        )
                    }
                }
                if (property.ownerVerified) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = VerifiedJade, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "Verified Owner: ${property.ownerName} ${property.ownerPhoneMasked}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                Text(strings.bookingDurationsLabel, style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    durations.forEach { months ->
                        FilterChip(
                            selected = selectedDuration == months,
                            onClick = { selectedDuration = months },
                            label = { Text("$months Months") }
                        )
                    }
                }
                Text(
                    text = strings.firstMonthRentNotice,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = strings.secondMonthZeroFeeNotice,
                    style = MaterialTheme.typography.bodySmall,
                    color = VerifiedJade
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onRequestBooking(selectedDuration) },
                enabled = property.occupancyStatus == "AVAILABLE",
                colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald)
            ) {
                Text("Book ($selectedDuration mo)")
            }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { onRequestVisit(selectedDuration) }) {
                    Text("Request Visit")
                }
                TextButton(onClick = onDismiss) {
                    Text("Close")
                }
            }
        }
    )
}

@Composable
fun PaymentOrderCheckoutDialog(
    order: PaymentOrder,
    onDismiss: () -> Unit,
    onMarkFailedOrCancelled: (status: String, reason: String) -> Unit
) {
    val context = LocalContext.current
    var cancelReason by rememberSaveable { mutableStateOf("Payment abandoned by user") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Payment Order • ${formatInr(order.amountInr)}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Receipt Ref: ${order.receiptRef}",
                    style = MonoTextStyle
                )
                Text(
                    text = "Status: ${order.paymentStatus}",
                    style = MaterialTheme.typography.labelLarge,
                    color = AmberWarning
                )
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Security Policy: Nest Haven never fakes payment success in the app. Live ₹99/rent capture and automatic 24-hour payouts require connecting Merchant Payment Gateway API keys (e.g., Razorpay/Cashfree) and a server webhook.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                OutlinedTextField(
                    value = cancelReason,
                    onValueChange = { cancelReason = it },
                    label = { Text("Failure / Cancellation Note") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = {
                        val upiUri = Uri.parse(
                            "upi://pay?pa=nesthaven@upi&pn=NestHaven&tr=${order.receiptRef}&am=${order.amountInr}&cu=INR"
                        )
                        val intent = Intent(Intent.ACTION_VIEW, upiUri)
                        runCatching { context.startActivity(intent) }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.CurrencyRupee, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Launch UPI App Intent")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Keep Awaiting Verification")
            }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TextButton(
                    onClick = { onMarkFailedOrCancelled("FAILED", cancelReason) },
                    colors = ButtonDefaults.textButtonColors(contentColor = CrimsonAlert)
                ) {
                    Text("Mark Failed")
                }
                TextButton(
                    onClick = { onMarkFailedOrCancelled("CANCELLED", cancelReason) }
                ) {
                    Text("Cancel Order")
                }
            }
        }
    )
}
