package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.model.ComplaintTicket
import com.example.data.model.NotificationItem
import com.example.data.model.PortalRole
import com.example.data.model.StayReview
import com.example.data.model.UserSecurityProfile
import com.example.security.SecurityCrypto
import com.example.ui.components.EmptyVaultState
import com.example.ui.components.PasswordStrengthMeter
import com.example.ui.components.RoleBadge
import com.example.ui.components.SectionHeader
import com.example.ui.components.SecurityStatusPill
import com.example.ui.components.TotpAuthenticatorWidget
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppLocalization
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.DeepEmerald
import com.example.ui.theme.VerifiedJade

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AlertsAndSupportScreen(
    language: AppLanguage,
    notifications: List<NotificationItem>,
    complaints: List<ComplaintTicket>,
    isBusy: Boolean,
    onMarkNotificationRead: (String) -> Unit,
    onSubmitComplaint: (category: String, subject: String, description: String) -> Unit
) {
    val strings = AppLocalization.get(language)
    var category by rememberSaveable { mutableStateOf("PROPERTY") }
    var subject by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }

    val categories = listOf("PROPERTY", "PAYMENT", "REFUND", "SAFETY", "OWNER_TENANT", "OTHER")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(modifier = Modifier.widthIn(max = 760.dp)) {
                    SectionHeader(
                        title = strings.notificationsTitle,
                        subtitle = "Booking, rent reminder, payment, refund & availability alerts"
                    )
                }
            }
        }

        if (notifications.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    EmptyVaultState(
                        icon = Icons.Filled.Notifications,
                        title = "No Alerts Yet",
                        message = "Notifications for bookings, payments, rent reminders, and refunds will appear here.",
                        modifier = Modifier.widthIn(max = 760.dp)
                    )
                }
            }
        } else {
            items(notifications, key = { it.id }) { notif ->
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 760.dp)
                            .clickable(enabled = !notif.readFlag) { onMarkNotificationRead(notif.id) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (notif.readFlag) {
                                MaterialTheme.colorScheme.surface
                            } else {
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                            }
                        ),
                        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = if (notif.readFlag) Icons.Filled.MarkEmailRead else Icons.Filled.AddAlert,
                                contentDescription = notif.category,
                                tint = if (notif.readFlag) MaterialTheme.colorScheme.onSurfaceVariant else DeepEmerald,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = notif.title,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    SecurityStatusPill(
                                        label = notif.category,
                                        isPositive = notif.readFlag
                                    )
                                }
                                Text(
                                    text = notif.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 760.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.55f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.SupportAgent, contentDescription = null, tint = DeepEmerald)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = strings.complaintsSupport,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            categories.forEach { cat ->
                                FilterChip(
                                    selected = category == cat,
                                    onClick = { category = cat },
                                    label = { Text(cat.replace("_", " ")) }
                                )
                            }
                        }
                        OutlinedTextField(
                            value = subject,
                            onValueChange = { subject = it },
                            label = { Text("Subject (min 3 characters)") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("complaint_subject_input")
                        )
                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Describe the issue (min 5 characters)") },
                            minLines = 3,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("complaint_description_input")
                        )
                        Button(
                            onClick = {
                                onSubmitComplaint(category, subject, description)
                                subject = ""
                                description = ""
                            },
                            enabled = !isBusy && subject.trim().length >= 3 && description.trim().length >= 5,
                            colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("submit_complaint_button")
                        ) {
                            Icon(Icons.Filled.ReportProblem, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(strings.submitComplaint)
                        }
                    }
                }
            }
        }

        if (complaints.isNotEmpty()) {
            items(complaints, key = { it.id }) { ticket ->
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 760.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = ticket.subject,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                SecurityStatusPill(
                                    label = ticket.status,
                                    isPositive = ticket.status == "RESOLVED" || ticket.status == "CLOSED"
                                )
                            }
                            Text(
                                text = "${ticket.category} • ${ticket.description}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (ticket.adminResolutionNote.isNotBlank()) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = "Support Resolution: ${ticket.adminResolutionNote}",
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.padding(8.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileAndReviewsScreen(
    language: AppLanguage,
    activeRole: PortalRole,
    profile: UserSecurityProfile?,
    totpSecret: String,
    reviewsAboutMe: List<StayReview>,
    isBusy: Boolean,
    onLanguageChange: (AppLanguage) -> Unit,
    onUpdateProfile: (displayName: String, phone: String, role: PortalRole, language: AppLanguage) -> Unit,
    onEnableOptional2FA: (passphrase: String, totpCode: String) -> Unit,
    onSignOut: () -> Unit
) {
    val strings = AppLocalization.get(language)
    var displayName by rememberSaveable(profile?.displayName) {
        mutableStateOf(profile?.displayName.orEmpty())
    }
    var phone by rememberSaveable(profile?.phone) {
        mutableStateOf(profile?.phone.orEmpty())
    }
    var selectedRole by rememberSaveable(activeRole) { mutableStateOf(activeRole) }

    var showSecuritySetup by rememberSaveable { mutableStateOf(false) }
    var passphrase by rememberSaveable { mutableStateOf("") }
    var totpCode by rememberSaveable { mutableStateOf("") }
    val strength = remember(passphrase) { SecurityCrypto.validatePasswordStrength(passphrase) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(modifier = Modifier.widthIn(max = 760.dp)) {
                    SectionHeader(
                        title = strings.profileTitle,
                        subtitle = profile?.email ?: ""
                    )
                }
            }
        }

        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 760.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.55f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Person, contentDescription = null, tint = DeepEmerald)
                                Spacer(Modifier.width(8.dp))
                                RoleBadge(
                                    role = selectedRole,
                                    verifiedOwner = (profile?.ownerApproved == true && profile.kycVerified)
                                )
                            }
                            LanguageTogglePill(
                                selectedLanguage = language,
                                onLanguageChange = onLanguageChange
                            )
                        }

                        OutlinedTextField(
                            value = displayName,
                            onValueChange = { displayName = it },
                            label = { Text("Full Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("Phone Number (e.g. +91...)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text("Account Portal Mode", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = selectedRole == PortalRole.TENANT,
                                onClick = { selectedRole = PortalRole.TENANT },
                                label = { Text("TENANT") }
                            )
                            FilterChip(
                                selected = selectedRole == PortalRole.OWNER,
                                onClick = { selectedRole = PortalRole.OWNER },
                                label = { Text("PROPERTY OWNER") }
                            )
                        }

                        Button(
                            onClick = { onUpdateProfile(displayName, phone, selectedRole, language) },
                            enabled = !isBusy && displayName.trim().isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("save_profile_button")
                        ) {
                            Text("Save Profile & Switch Mode")
                        }
                    }
                }
            }
        }

        // Optional Account Security & 2FA
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 760.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Security, contentDescription = null, tint = DeepEmerald)
                                Spacer(Modifier.width(8.dp))
                                Text("Account 2FA & Passphrase", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            }
                            SecurityStatusPill(
                                label = if (profile?.totpEnabled == true) "2FA Active" else "Optional",
                                isPositive = profile?.totpEnabled == true
                            )
                        }

                        if (!showSecuritySetup && profile?.totpEnabled != true) {
                            OutlinedButton(
                                onClick = { showSecuritySetup = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Enable Hardware Keystore 2FA & Passphrase")
                            }
                        } else if (showSecuritySetup) {
                            TotpAuthenticatorWidget(secret = totpSecret, onCopyCode = {})
                            OutlinedTextField(
                                value = passphrase,
                                onValueChange = { passphrase = it },
                                label = { Text("Strong Passphrase") },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            PasswordStrengthMeter(strength = strength)
                            OutlinedTextField(
                                value = totpCode,
                                onValueChange = { totpCode = it },
                                label = { Text("Enter 6-Digit 2FA Code") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(
                                onClick = {
                                    onEnableOptional2FA(passphrase, totpCode)
                                    showSecuritySetup = false
                                },
                                enabled = strength.isStrong && totpCode.trim().length == 6 && !isBusy,
                                colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Activate 2FA Protection")
                            }
                        }
                    }
                }
            }
        }

        // Verified Ratings & Reviews
        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                SectionHeader(
                    title = strings.ratingsTitle,
                    subtitle = "Verified completed-stay ratings on your profile",
                    modifier = Modifier.widthIn(max = 760.dp)
                )
            }
        }

        if (reviewsAboutMe.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    EmptyVaultState(
                        icon = Icons.Filled.Star,
                        title = "No Verified Reviews Yet",
                        message = "Ratings can be submitted strictly once per completed booking to prevent spam or fake reviews.",
                        modifier = Modifier.widthIn(max = 760.dp)
                    )
                }
            }
        } else {
            items(reviewsAboutMe, key = { it.id }) { rev ->
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 760.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.45f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                repeat(rev.rating.toInt().coerceIn(1, 5)) {
                                    Icon(Icons.Filled.Star, contentDescription = null, tint = ChampagneGold, modifier = Modifier.size(16.dp))
                                }
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "By ${rev.reviewerRole}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = VerifiedJade
                                )
                            }
                            Text(rev.comment, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }

        item {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(modifier = Modifier.widthIn(max = 760.dp)) {
                    HorizontalDivider()
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = onSignOut,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonAlert),
                        border = BorderStroke(1.dp, CrimsonAlert.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("sign_out_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.signOut)
                    }
                }
            }
        }
    }
}
