package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.data.firebase.AuthManager
import com.example.data.model.PortalRole
import com.example.data.model.UserSecurityProfile
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppLocalization
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneGoldSoft
import com.example.ui.theme.DeepEmerald
import com.example.ui.theme.IvoryOnDark
import com.example.ui.theme.MutedSageOnDark
import com.example.ui.theme.VerifiedJade
import com.example.ui.theme.VerifiedJadeContainer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class AuthScreenTab {
    LOGIN,
    REGISTER
}

private enum class LoginViewMode {
    EMAIL_PASSWORD,
    FORGOT_PASSWORD,
    EMAIL_VERIFICATION_REQUIRED
}

@Composable
fun NestHavenLoginRegisterScreen(
    language: AppLanguage,
    activeSessionLabel: String?,
    isSessionEmailVerified: Boolean = false,
    onLanguageChange: (AppLanguage) -> Unit,
    onContinueActiveSession: () -> Unit,
    onSignOutActiveSession: () -> Unit = {},
    onAuthSucceededToHomepage: (role: PortalRole?, regName: String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val strings = AppLocalization.get(language)

    var activeTab by rememberSaveable { mutableStateOf(AuthScreenTab.LOGIN) }
    var loginViewMode by rememberSaveable { mutableStateOf(LoginViewMode.EMAIL_PASSWORD) }

    // Email & Password Login state
    var loginEmail by rememberSaveable { mutableStateOf("") }
    var loginPassword by rememberSaveable { mutableStateOf("") }
    var passwordVisible by rememberSaveable { mutableStateOf(false) }

    // Forgot Password state
    var resetEmailInput by rememberSaveable { mutableStateOf("") }

    // Email Verification Required state
    var pendingVerificationEmail by rememberSaveable { mutableStateOf("") }
    var resendCooldown by rememberSaveable { mutableIntStateOf(0) }

    var isBusy by remember { mutableStateOf(false) }
    var loginError by remember { mutableStateOf<String?>(null) }
    var loginInfo by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(resendCooldown) {
        if (resendCooldown > 0) {
            delay(1000L)
            resendCooldown -= 1
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepEmerald)
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_himalayan_sadhu_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF041711).copy(alpha = 0.90f),
                            DeepEmerald.copy(alpha = 0.88f),
                            Color(0xFF04140F).copy(alpha = 0.96f)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top bar: Nest Haven emblem + name + language pill
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 540.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_launcher_emblem),
                        contentDescription = "Nest Haven Logo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .border(2.dp, ChampagneGold, RoundedCornerShape(14.dp))
                    )
                    Column {
                        Text(
                            text = strings.appName,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = ChampagneGoldSoft
                        )
                        Text(
                            text = strings.tagline,
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedSageOnDark
                        )
                    }
                }
                LanguageTogglePill(
                    selectedLanguage = language,
                    onLanguageChange = onLanguageChange
                )
            }

            Spacer(Modifier.height(16.dp))

            Text(
                text = strings.welcomeToNestHaven,
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = ChampagneGoldSoft,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = strings.findYourPerfectStay,
                style = MaterialTheme.typography.bodyLarge,
                color = IvoryOnDark.copy(alpha = 0.90f),
                textAlign = TextAlign.Center
            )

            // Returning user active session bar
            if (!activeSessionLabel.isNullOrBlank()) {
                Spacer(Modifier.height(12.dp))
                Surface(
                    color = Color(0xFF0A2E23),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.7f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 540.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isSessionEmailVerified) {
                                    "Signed in: $activeSessionLabel"
                                } else {
                                    "Verification pending: $activeSessionLabel"
                                },
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = ChampagneGoldSoft
                            )
                            Text(
                                text = if (isSessionEmailVerified) {
                                    "Tap Continue or sign in with another email below"
                                } else {
                                    "Verify your email address to unlock Nest Haven"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedSageOnDark
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (isSessionEmailVerified) {
                                    onContinueActiveSession()
                                } else {
                                    activeTab = AuthScreenTab.LOGIN
                                    pendingVerificationEmail = activeSessionLabel
                                    loginViewMode = LoginViewMode.EMAIL_VERIFICATION_REQUIRED
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ChampagneGold,
                                contentColor = DeepEmerald
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("continue_active_session_button")
                        ) {
                            Text(
                                text = if (isSessionEmailVerified) "Continue" else "Verify",
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.width(4.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Primary Auth Card (Email & Password Login / Registration)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 540.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.5.dp, ChampagneGold)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Login / Separate Register Mode Switcher
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                activeTab = AuthScreenTab.LOGIN
                                loginError = null
                                loginInfo = null
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (activeTab == AuthScreenTab.LOGIN) DeepEmerald else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (activeTab == AuthScreenTab.LOGIN) ChampagneGoldSoft else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("open_login_button")
                        ) {
                            Text(strings.loginTabLabel, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                activeTab = AuthScreenTab.REGISTER
                                loginError = null
                                loginInfo = null
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (activeTab == AuthScreenTab.REGISTER) ChampagneGoldSoft else Color.Transparent,
                                contentColor = DeepEmerald
                            ),
                            border = BorderStroke(1.5.dp, if (activeTab == AuthScreenTab.REGISTER) DeepEmerald else ChampagneGold),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("open_register_button")
                        ) {
                            Icon(Icons.Filled.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.registerButtonLabel, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (activeTab == AuthScreenTab.REGISTER) {
                        RegistrationFormSection(
                            language = language,
                            onBackToLogin = {
                                activeTab = AuthScreenTab.LOGIN
                                loginViewMode = LoginViewMode.EMAIL_PASSWORD
                            },
                            onRegistrationSuccess = { role, name ->
                                onAuthSucceededToHomepage(role, name)
                            }
                        )
                    } else {
                        when (loginViewMode) {
                            LoginViewMode.EMAIL_PASSWORD -> {
                                Surface(
                                    color = ChampagneGoldSoft.copy(alpha = 0.7f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, ChampagneGold)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            Icons.Filled.Email,
                                            contentDescription = null,
                                            tint = DeepEmerald,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = strings.loginWithEmailLabel,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                            color = DeepEmerald
                                        )
                                    }
                                }

                                OutlinedTextField(
                                    value = loginEmail,
                                    onValueChange = { loginEmail = it; loginError = null },
                                    label = { Text("Email Address") },
                                    leadingIcon = { Icon(Icons.Filled.Email, contentDescription = "Email Address") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("email_login_input")
                                )

                                OutlinedTextField(
                                    value = loginPassword,
                                    onValueChange = { loginPassword = it; loginError = null },
                                    label = { Text("Password") },
                                    leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Password") },
                                    trailingIcon = {
                                        IconButton(
                                            onClick = { passwordVisible = !passwordVisible },
                                            modifier = Modifier.testTag("login_password_visibility_toggle")
                                        ) {
                                            Icon(
                                                imageVector = if (passwordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                                contentDescription = if (passwordVisible) "Hide Password" else "Show Password"
                                            )
                                        }
                                    },
                                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("password_login_input")
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(
                                        onClick = {
                                            resetEmailInput = loginEmail.trim()
                                            loginError = null
                                            loginInfo = null
                                            loginViewMode = LoginViewMode.FORGOT_PASSWORD
                                        },
                                        modifier = Modifier
                                            .minimumInteractiveComponentSize()
                                            .testTag("forgot_password_button")
                                    ) {
                                        Text(strings.forgotPasswordLabel)
                                    }
                                }

                                Button(
                                    onClick = {
                                        val cleanEmail = loginEmail.trim().lowercase()
                                        if (!AuthManager.isValidEmail(cleanEmail)) {
                                            loginError = "Enter a valid email address."
                                            return@Button
                                        }
                                        if (loginPassword.isBlank()) {
                                            loginError = "Enter your password."
                                            return@Button
                                        }
                                        loginError = null
                                        loginInfo = null
                                        isBusy = true
                                        scope.launch {
                                            AuthManager.signInWithEmailPassword(cleanEmail, loginPassword).fold(
                                                onSuccess = { user ->
                                                    isBusy = false
                                                    if (user.isEmailVerified) {
                                                        onAuthSucceededToHomepage(null, user.displayName.orEmpty())
                                                    } else {
                                                        pendingVerificationEmail = user.email ?: cleanEmail
                                                        loginViewMode = LoginViewMode.EMAIL_VERIFICATION_REQUIRED
                                                        loginInfo = "Please verify your email address (${pendingVerificationEmail}) before entering Nest Haven."
                                                    }
                                                },
                                                onFailure = { err ->
                                                    isBusy = false
                                                    loginError = err.localizedMessage ?: "Login failed. Please check your email and password."
                                                }
                                            )
                                        }
                                    },
                                    enabled = !isBusy,
                                    colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .minimumInteractiveComponentSize()
                                        .testTag("email_login_button")
                                ) {
                                    if (isBusy) {
                                        CircularProgressIndicator(Modifier.size(20.dp), color = ChampagneGoldSoft, strokeWidth = 2.dp)
                                        Spacer(Modifier.width(8.dp))
                                    }
                                    Text(strings.loginButtonLabel, fontWeight = FontWeight.Bold)
                                }
                            }

                            LoginViewMode.FORGOT_PASSWORD -> {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Filled.LockReset, contentDescription = null, tint = DeepEmerald)
                                    Text(
                                        text = strings.resetPasswordTitle,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = DeepEmerald
                                    )
                                }
                                Text(
                                    text = "Enter your registered email address. Firebase will send you a password reset link.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                OutlinedTextField(
                                    value = resetEmailInput,
                                    onValueChange = { resetEmailInput = it; loginError = null },
                                    label = { Text("Registered Email Address") },
                                    leadingIcon = { Icon(Icons.Filled.Email, contentDescription = "Registered Email") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("reset_password_email_input")
                                )

                                Button(
                                    onClick = {
                                        val cleanEmail = resetEmailInput.trim().lowercase()
                                        if (!AuthManager.isValidEmail(cleanEmail)) {
                                            loginError = "Enter a valid registered email address."
                                            return@Button
                                        }
                                        loginError = null
                                        loginInfo = null
                                        isBusy = true
                                        scope.launch {
                                            AuthManager.sendPasswordResetEmail(cleanEmail).fold(
                                                onSuccess = {
                                                    isBusy = false
                                                    loginInfo = "Password reset link sent to $cleanEmail. Check your inbox and spam folder, reset your password, and return here to log in."
                                                },
                                                onFailure = { err ->
                                                    isBusy = false
                                                    loginError = err.localizedMessage ?: "Unable to send password reset email."
                                                }
                                            )
                                        }
                                    },
                                    enabled = !isBusy,
                                    colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .minimumInteractiveComponentSize()
                                        .testTag("send_reset_password_button")
                                ) {
                                    if (isBusy) {
                                        CircularProgressIndicator(Modifier.size(20.dp), color = ChampagneGoldSoft, strokeWidth = 2.dp)
                                        Spacer(Modifier.width(8.dp))
                                    }
                                    Text(strings.sendResetEmailLabel, fontWeight = FontWeight.Bold)
                                }

                                TextButton(
                                    onClick = {
                                        loginError = null
                                        loginViewMode = LoginViewMode.EMAIL_PASSWORD
                                    },
                                    modifier = Modifier
                                        .align(Alignment.CenterHorizontally)
                                        .testTag("back_from_reset_button")
                                ) {
                                    Text("Back to Login")
                                }
                            }

                            LoginViewMode.EMAIL_VERIFICATION_REQUIRED -> {
                                Surface(
                                    color = VerifiedJadeContainer.copy(alpha = 0.7f),
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, VerifiedJade),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("email_verification_panel")
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(Icons.Filled.MarkEmailRead, contentDescription = null, tint = VerifiedJade)
                                            Text(
                                                text = strings.verifyEmailTitle,
                                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                                color = DeepEmerald
                                            )
                                        }
                                        Text(
                                            text = "Verification is required for $pendingVerificationEmail. Open the verification email in your inbox, click the link, then tap Continue.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = DeepEmerald
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        loginError = null
                                        isBusy = true
                                        scope.launch {
                                            AuthManager.reloadAndCheckEmailVerified().fold(
                                                onSuccess = { verified ->
                                                    isBusy = false
                                                    if (verified) {
                                                        onAuthSucceededToHomepage(null, "")
                                                    } else {
                                                        loginError = "Email is still unverified. Click the link in your inbox or resend the verification email below."
                                                    }
                                                },
                                                onFailure = { err ->
                                                    isBusy = false
                                                    loginError = err.localizedMessage ?: "Could not refresh verification status."
                                                }
                                            )
                                        }
                                    },
                                    enabled = !isBusy,
                                    colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .minimumInteractiveComponentSize()
                                        .testTag("check_email_verified_button")
                                ) {
                                    if (isBusy) {
                                        CircularProgressIndicator(Modifier.size(18.dp), color = ChampagneGoldSoft, strokeWidth = 2.dp)
                                        Spacer(Modifier.width(8.dp))
                                    }
                                    Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(strings.checkVerifiedLabel, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        loginError = null
                                        isBusy = true
                                        scope.launch {
                                            AuthManager.sendVerificationEmail().fold(
                                                onSuccess = {
                                                    isBusy = false
                                                    resendCooldown = 60
                                                    loginInfo = "Verification email sent to $pendingVerificationEmail."
                                                },
                                                onFailure = { err ->
                                                    isBusy = false
                                                    loginError = err.localizedMessage ?: "Failed to send verification email."
                                                }
                                            )
                                        }
                                    },
                                    enabled = resendCooldown == 0 && !isBusy,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .minimumInteractiveComponentSize()
                                        .testTag("resend_verification_email_button")
                                ) {
                                    Text(
                                        if (resendCooldown > 0) "${strings.resendVerificationLabel} (${resendCooldown}s)"
                                        else strings.resendVerificationLabel
                                    )
                                }

                                TextButton(
                                    onClick = {
                                        AuthManager.signOut(credentialManager = credentialManager, scope = scope) {
                                            loginError = null
                                            loginInfo = null
                                            loginViewMode = LoginViewMode.EMAIL_PASSWORD
                                            onSignOutActiveSession()
                                        }
                                    },
                                    modifier = Modifier
                                        .align(Alignment.CenterHorizontally)
                                        .testTag("verification_sign_out_button")
                                ) {
                                    Text("Use Another Account")
                                }
                            }
                        }

                        if (!loginInfo.isNullOrBlank()) {
                            Surface(
                                color = ChampagneGoldSoft,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, ChampagneGold)
                            ) {
                                Text(
                                    text = loginInfo.orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = DeepEmerald,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp)
                                )
                            }
                        }

                        if (!loginError.isNullOrBlank()) {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = loginError.orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Text(
                text = "Secured by Firebase Email Authentication",
                style = MaterialTheme.typography.labelSmall,
                color = MutedSageOnDark,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun LanguageTogglePill(
    selectedLanguage: AppLanguage,
    onLanguageChange: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color(0xFF0A261D),
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.55f)),
        modifier = modifier.testTag("language_toggle_pill")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(4.dp)
        ) {
            Icon(
                Icons.Filled.Language,
                contentDescription = "Switch Language",
                tint = ChampagneGold,
                modifier = Modifier
                    .padding(start = 8.dp, end = 4.dp)
                    .size(16.dp)
            )
            AppLanguage.entries.forEach { lang ->
                val selected = lang == selectedLanguage
                Surface(
                    color = if (selected) ChampagneGold else Color.Transparent,
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .clickable { onLanguageChange(lang) }
                ) {
                    Text(
                        text = lang.displayLabel,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (selected) DeepEmerald else ChampagneGoldSoft,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun PublicTwoFactorUnlockScreen(
    email: String,
    profile: UserSecurityProfile,
    onUnlock: (passphrase: String, code: String, profile: UserSecurityProfile) -> Unit,
    onSignOut: () -> Unit
) {
    var passphrase by rememberSaveable { mutableStateOf("") }
    var totpCode by rememberSaveable { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 460.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Lock, contentDescription = null, tint = DeepEmerald)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "2FA Account Verification",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Text(
                    text = "You enabled optional 2FA & passphrase protection on $email.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = passphrase,
                    onValueChange = { passphrase = it },
                    label = { Text("Security Passphrase") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = totpCode,
                    onValueChange = { totpCode = it },
                    label = { Text("6-Digit 2FA or Recovery Code") },
                    leadingIcon = { Icon(Icons.Filled.Key, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { onUnlock(passphrase, totpCode, profile) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("unlock_2fa_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = DeepEmerald)
                ) {
                    Text("Verify & Continue")
                }
                TextButton(onClick = onSignOut, modifier = Modifier.align(Alignment.End)) {
                    Text("Sign Out")
                }
            }
        }
    }
}
