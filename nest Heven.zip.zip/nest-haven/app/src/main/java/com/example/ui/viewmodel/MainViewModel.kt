package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.NestHavenRepository
import com.example.data.model.BookingRequest
import com.example.data.model.ComplaintTicket
import com.example.data.model.NotificationItem
import com.example.data.model.PaymentOrder
import com.example.data.model.PortalRole
import com.example.data.model.PropertyRecord
import com.example.data.model.PublicSessionState
import com.example.data.model.SearchUnlock
import com.example.data.model.StayReview
import com.example.data.model.UiState
import com.example.data.model.UserSecurityProfile
import com.example.security.LocalVaultStore
import com.example.security.SecurityCrypto
import com.example.ui.i18n.AppLanguage
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(
    private val repository: NestHavenRepository,
    private val vaultStore: LocalVaultStore,
    private val currentUserId: String,
    initialPortalRole: PortalRole,
    initialLanguage: AppLanguage,
    private val initialRegistrationName: String = "",
    private val initialRegistrationPhone: String = ""
) : ViewModel() {

    private val _selectedPortalRole = MutableStateFlow(initialPortalRole)
    val selectedPortalRole: StateFlow<PortalRole> = _selectedPortalRole.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(initialLanguage)
    val selectedLanguage: StateFlow<AppLanguage> = _selectedLanguage.asStateFlow()

    private val _sessionState = MutableStateFlow<UiState<PublicSessionState>>(UiState.Loading)
    val sessionState: StateFlow<UiState<PublicSessionState>> = _sessionState.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private val _twoFactorUnlocked = MutableStateFlow(true)
    val twoFactorUnlocked: StateFlow<Boolean> = _twoFactorUnlocked.asStateFlow()

    private val _activeTotpSecret = MutableStateFlow(vaultStore.getOrCreateTotpSecret(currentUserId))
    val activeTotpSecret: StateFlow<String> = _activeTotpSecret.asStateFlow()

    private val _generatedRecoveryCodes = MutableStateFlow<List<String>>(emptyList())
    val generatedRecoveryCodes: StateFlow<List<String>> = _generatedRecoveryCodes.asStateFlow()

    val userProfileState: StateFlow<UiState<UserSecurityProfile?>> =
        repository.observeUserProfile(currentUserId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val publishedPropertiesState: StateFlow<UiState<List<PropertyRecord>>> =
        repository.observePublishedProperties()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val ownerPropertiesState: StateFlow<UiState<List<PropertyRecord>>> =
        userProfileState.flatMapLatest { profileUi ->
            val profile = (profileUi as? UiState.Success)?.data
            if (profile != null && profile.ownerApproved && profile.kycVerified) {
                repository.observeOwnerProperties(currentUserId)
            } else {
                flowOf(UiState.Success(emptyList()))
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val searchUnlocksState: StateFlow<UiState<List<SearchUnlock>>> =
        repository.observeTenantSearchUnlocks(currentUserId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val tenantBookingsState: StateFlow<UiState<List<BookingRequest>>> =
        repository.observeTenantBookings(currentUserId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val ownerBookingsState: StateFlow<UiState<List<BookingRequest>>> =
        userProfileState.flatMapLatest { profileUi ->
            val profile = (profileUi as? UiState.Success)?.data
            if (profile != null && profile.ownerApproved && profile.kycVerified) {
                repository.observeOwnerBookings(currentUserId)
            } else {
                flowOf(UiState.Success(emptyList()))
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val tenantPaymentOrdersState: StateFlow<UiState<List<PaymentOrder>>> =
        repository.observeTenantPaymentOrders(currentUserId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val ownerPaymentOrdersState: StateFlow<UiState<List<PaymentOrder>>> =
        userProfileState.flatMapLatest { profileUi ->
            val profile = (profileUi as? UiState.Success)?.data
            if (profile != null && profile.ownerApproved && profile.kycVerified) {
                repository.observeOwnerPaymentOrders(currentUserId)
            } else {
                flowOf(UiState.Success(emptyList()))
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val notificationsState: StateFlow<UiState<List<NotificationItem>>> =
        repository.observeNotifications(currentUserId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val complaintsState: StateFlow<UiState<List<ComplaintTicket>>> =
        repository.observeMyComplaints(currentUserId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val myReviewsState: StateFlow<UiState<List<StayReview>>> =
        repository.observeReviewsByReviewer(currentUserId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val reviewsAboutMeState: StateFlow<UiState<List<StayReview>>> =
        repository.observeReviewsForTarget(currentUserId)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    init {
        refreshSession()
    }

    fun refreshSession() {
        viewModelScope.launch {
            _sessionState.value = UiState.Loading
            repository.loadOrCreatePublicSession(
                preferredRole = _selectedPortalRole.value,
                preferredLanguageCode = _selectedLanguage.value.code,
                registrationName = initialRegistrationName,
                registrationPhone = initialRegistrationPhone
            ).fold(
                onSuccess = { session ->
                    _sessionState.value = UiState.Success(session)
                    if (session.profile.totpEnabled) {
                        _twoFactorUnlocked.value = false
                    }
                },
                onFailure = { error ->
                    _sessionState.value = UiState.Error(error.localizedMessage ?: "Failed to load account.")
                }
            )
        }
    }

    fun syncPortalEntry(
        role: PortalRole,
        language: AppLanguage,
        regName: String = "",
        regPhone: String = ""
    ) {
        _selectedPortalRole.value = role
        _selectedLanguage.value = language
        viewModelScope.launch {
            val existing = activeProfileOrNull()
            val resolvedName = regName.trim().ifBlank { existing?.displayName.orEmpty() }
            val resolvedPhone = regPhone.trim().ifBlank { existing?.phone.orEmpty() }
            if (resolvedName.isNotBlank()) {
                repository.updateProfilePreferences(
                    uid = currentUserId,
                    displayName = resolvedName,
                    phone = resolvedPhone,
                    accountType = role,
                    preferredLanguageCode = language.code
                )
            }
        }
    }

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    fun dismissRecoveryCodes() {
        _generatedRecoveryCodes.value = emptyList()
    }

    fun setLanguage(language: AppLanguage) {
        _selectedLanguage.value = language
        val profile = activeProfileOrNull() ?: return
        viewModelScope.launch {
            repository.updateProfilePreferences(
                uid = currentUserId,
                displayName = profile.displayName,
                phone = profile.phone,
                accountType = _selectedPortalRole.value,
                preferredLanguageCode = language.code
            )
        }
    }

    fun switchPortalRole(role: PortalRole) {
        _selectedPortalRole.value = role
        val profile = activeProfileOrNull() ?: return
        viewModelScope.launch {
            repository.updateProfilePreferences(
                uid = currentUserId,
                displayName = profile.displayName,
                phone = profile.phone,
                accountType = role,
                preferredLanguageCode = _selectedLanguage.value.code
            ).onFailure { err ->
                _feedbackMessage.value = err.localizedMessage ?: "Unable to switch role."
            }
        }
    }

    fun updateProfile(displayName: String, phone: String, accountType: PortalRole, language: AppLanguage) {
        _selectedPortalRole.value = accountType
        _selectedLanguage.value = language
        runBusyAction(successMessage = "Profile updated.") {
            repository.updateProfilePreferences(
                uid = currentUserId,
                displayName = displayName,
                phone = phone,
                accountType = accountType,
                preferredLanguageCode = language.code
            )
        }
    }

    fun enableOptionalSecurity2FA(passphrase: String, totpCode: String) {
        val strength = SecurityCrypto.validatePasswordStrength(passphrase)
        if (!strength.isStrong) {
            _feedbackMessage.value = "Password must be at least 12 characters with upper, lower, digit, and symbol."
            return
        }
        val secret = _activeTotpSecret.value
        if (!SecurityCrypto.verifyTotpCode(secret, totpCode)) {
            _feedbackMessage.value = "Invalid 6-digit 2FA code."
            return
        }
        val session = (_sessionState.value as? UiState.Success)?.data ?: return
        val salt = SecurityCrypto.generateSalt()
        val hash = SecurityCrypto.hashPassphrase(passphrase, salt)
        val codes = SecurityCrypto.generateRecoveryCodes(6)
        vaultStore.saveRecoveryCodeHashes(currentUserId, codes.map { SecurityCrypto.sha256Hex(it) })

        runBusyAction(successMessage = "2FA & strong passphrase enabled.") {
            repository.updateOptionalSecurityProtection(
                uid = currentUserId,
                email = session.email,
                masterUid = session.masterUid,
                roleLabel = _selectedPortalRole.value.name,
                passwordHash = hash,
                passwordSalt = salt,
                totpEnabled = true,
                recoveryCodesCount = codes.size.toLong()
            ).onSuccess {
                _generatedRecoveryCodes.value = codes
                _twoFactorUnlocked.value = true
            }
        }
    }

    fun unlockWith2FA(passphrase: String, codeOrRecovery: String, profile: UserSecurityProfile) {
        if (!SecurityCrypto.verifyPassphrase(passphrase, profile.vaultPasswordSalt, profile.vaultPasswordHash)) {
            _feedbackMessage.value = "Incorrect security passphrase."
            return
        }
        val trimmed = codeOrRecovery.trim()
        val secret = _activeTotpSecret.value
        val ok = SecurityCrypto.verifyTotpCode(secret, trimmed) || vaultStore.consumeRecoveryCode(currentUserId, trimmed)
        if (!ok) {
            _feedbackMessage.value = "Invalid 2FA code or recovery code."
            return
        }
        _twoFactorUnlocked.value = true
    }

    fun createSearchUnlockAnd99Order(
        state: String,
        city: String,
        locality: String,
        buildingFilter: String,
        monthlyBudgetInr: Long,
        roomPreference: String,
        requiredFacilities: List<String>,
        onOrderCreated: (unlockId: String, orderId: String) -> Unit
    ) {
        val session = (_sessionState.value as? UiState.Success)?.data ?: return
        runBusyAction {
            repository.createSearchUnlockAndOrder99(
                tenantUid = currentUserId,
                actorEmail = session.email,
                masterUid = session.masterUid,
                state = state,
                city = city,
                locality = locality,
                buildingFilter = buildingFilter,
                monthlyBudgetInr = monthlyBudgetInr,
                roomPreference = roomPreference,
                requiredFacilities = requiredFacilities
            ).onSuccess { (unlockId, orderId) ->
                _feedbackMessage.value = "₹99 search order created. Complete payment gateway verification to unlock."
                onOrderCreated(unlockId, orderId)
            }
        }
    }

    fun markPaymentOrderFailedOrCancelled(orderId: String, newStatus: String, reason: String) {
        runBusyAction(successMessage = "Payment status recorded as $newStatus.") {
            repository.markPaymentOrderFailedOrCancelled(orderId, newStatus, reason)
        }
    }

    fun acceptSearchAlternative(unlockId: String) {
        runBusyAction(successMessage = "Alternative accepted. ₹99 search fee is non-refundable per policy.") {
            repository.acceptSearchAlternative(unlockId)
        }
    }

    fun requestSearchRefund(unlockId: String) {
        runBusyAction(successMessage = "₹99 refund request submitted for anti-fraud verification.") {
            repository.requestSearchRefundVerification(unlockId, currentUserId)
        }
    }

    fun createBookingOrVisitRequest(
        property: PropertyRecord,
        requestType: String,
        durationMonths: Long,
        onCreated: () -> Unit = {}
    ) {
        val session = (_sessionState.value as? UiState.Success)?.data ?: return
        val profile = activeProfileOrNull()
        val displayName = profile?.displayName?.ifBlank { session.displayName } ?: session.displayName
        runBusyAction(
            successMessage = if (requestType == "VISIT") {
                "Visit request submitted to verified owner."
            } else {
                "Booking created for $durationMonths months. Pay 1st-month rent to confirm."
            }
        ) {
            repository.createBookingOrVisitRequest(
                property = property,
                tenantUid = currentUserId,
                tenantName = displayName,
                tenantEmail = session.email,
                masterUid = session.masterUid,
                requestType = requestType,
                durationMonths = durationMonths
            ).onSuccess { onCreated() }
        }
    }

    fun createMonthlyRentOrder(booking: BookingRequest, monthNumber: Long) {
        val session = (_sessionState.value as? UiState.Success)?.data ?: return
        runBusyAction(successMessage = "Month $monthNumber rent order ready (₹0 platform charges).") {
            repository.createMonthlyRentOrder(
                booking = booking,
                monthNumber = monthNumber,
                tenantEmail = session.email,
                masterUid = session.masterUid
            )
        }
    }

    fun cancelTenantBooking(bookingId: String, reason: String) {
        runBusyAction(successMessage = "Booking cancelled.") {
            repository.cancelTenantBooking(bookingId, reason)
        }
    }

    fun submitOwnerBookingDecision(booking: BookingRequest, approved: Boolean, note: String) {
        runBusyAction(
            successMessage = if (approved) "Request approved." else "Request rejected."
        ) {
            repository.submitOwnerBookingDecision(booking, approved, note)
        }
    }

    fun acknowledgeVerifiedRentReceipt(order: PaymentOrder) {
        runBusyAction(successMessage = "Rent receipt acknowledged.") {
            repository.acknowledgeVerifiedRentReceipt(order)
        }
    }

    fun markNotificationRead(notifId: String) {
        viewModelScope.launch {
            repository.markNotificationRead(notifId)
        }
    }

    fun submitComplaint(category: String, subject: String, description: String, onSuccess: () -> Unit = {}) {
        val session = (_sessionState.value as? UiState.Success)?.data ?: return
        val profile = activeProfileOrNull()
        val name = profile?.displayName?.ifBlank { session.displayName } ?: session.displayName
        runBusyAction(successMessage = "Complaint submitted to Nest Haven support.") {
            repository.submitComplaint(
                reporterUid = currentUserId,
                reporterRole = _selectedPortalRole.value,
                reporterName = name,
                reporterEmail = session.email,
                masterUid = session.masterUid,
                category = category,
                subject = subject,
                description = description
            ).onSuccess { onSuccess() }
        }
    }

    fun submitStayReview(booking: BookingRequest, rating: Long, comment: String, onSuccess: () -> Unit = {}) {
        runBusyAction(successMessage = "Verified stay review published.") {
            repository.submitStayReview(
                booking = booking,
                reviewerUid = currentUserId,
                reviewerRole = _selectedPortalRole.value,
                rating = rating,
                comment = comment
            ).onSuccess { onSuccess() }
        }
    }

    private fun activeProfileOrNull(): UserSecurityProfile? {
        val live = (userProfileState.value as? UiState.Success)?.data
        if (live != null) return live
        return (_sessionState.value as? UiState.Success)?.data?.profile
    }

    private fun <T> runBusyAction(
        successMessage: String? = null,
        block: suspend () -> Result<T>
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            block().fold(
                onSuccess = {
                    if (!successMessage.isNullOrBlank()) {
                        _feedbackMessage.value = successMessage
                    }
                },
                onFailure = { error ->
                    _feedbackMessage.value = error.localizedMessage ?: "Action failed."
                }
            )
            _isBusy.value = false
        }
    }
}
