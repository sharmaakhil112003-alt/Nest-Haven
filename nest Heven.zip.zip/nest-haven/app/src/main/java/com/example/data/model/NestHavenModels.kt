package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class PortalRole {
    TENANT,
    OWNER
}

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@Keep
@IgnoreExtraProperties
data class UserSecurityProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val displayName: String = "",
    val phone: String = "",
    val accountType: String = "TENANT",
    val preferredLanguage: String = "en",
    val role: String = "MEMBER",
    val ownerApproved: Boolean = false,
    val kycVerified: Boolean = false,
    val vaultPasswordHash: String = "",
    val vaultPasswordSalt: String = "",
    val totpEnabled: Boolean = false,
    val recoveryCodesCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PropertyRecord(
    @DocumentId val id: String = "",
    val masterUid: String = "",
    val name: String = "",
    val state: String = "",
    val city: String = "",
    val locality: String = "",
    val buildingName: String = "",
    val address: String = "",
    val roomNumber: String = "",
    val roomType: String = "SINGLE",
    val monthlyRentInr: Long = 0L,
    val facilities: List<String> = emptyList(),
    val photoUrls: List<String> = emptyList(),
    val occupancyStatus: String = "AVAILABLE",
    val published: Boolean = false,
    val ownerUid: String = "",
    val ownerName: String = "",
    val ownerPhoneMasked: String = "",
    val ownerVerified: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class SearchUnlock(
    @DocumentId val id: String = "",
    val tenantUid: String = "",
    val state: String = "",
    val city: String = "",
    val locality: String = "",
    val buildingFilter: String = "",
    val monthlyBudgetInr: Long = 6000L,
    val roomPreference: String = "ANY",
    val requiredFacilities: List<String> = emptyList(),
    val feeAmountInr: Long = 99L,
    val unlockStatus: String = "PAYMENT_PENDING",
    val alternativeOffered: Boolean = false,
    val alternativeRentInr: Long = 0L,
    val alternativeAccepted: Boolean = false,
    val refundStatus: String = "NONE",
    val paymentOrderId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class BookingRequest(
    @DocumentId val id: String = "",
    val propertyId: String = "",
    val propertyTitle: String = "",
    val localitySummary: String = "",
    val tenantUid: String = "",
    val tenantName: String = "",
    val ownerUid: String = "",
    val ownerName: String = "",
    val requestType: String = "BOOKING",
    val durationMonths: Long = 6L,
    val monthlyRentInr: Long = 0L,
    val firstMonthRentPaid: Boolean = false,
    val status: String = "PENDING_PAYMENT",
    val ownerDecision: String = "PENDING",
    val ownerDecisionNote: String = "",
    val cancellationReason: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PaymentOrder(
    @DocumentId val id: String = "",
    val tenantUid: String = "",
    val ownerUid: String = "",
    val bookingId: String = "",
    val searchUnlockId: String = "",
    val paymentPurpose: String = "SEARCH_FEE_99",
    val amountInr: Long = 99L,
    val platformFeeInr: Long = 0L,
    val rentMonthNumber: Long = 0L,
    val paymentStatus: String = "AWAITING_GATEWAY_VERIFICATION",
    val settlementStatus: String = "PENDING_VERIFICATION",
    val ownerVerifiedReceipt: Boolean = false,
    val receiptRef: String = "",
    val failureReason: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class NotificationItem(
    @DocumentId val id: String = "",
    val recipientUid: String = "",
    val category: String = "BOOKING",
    val title: String = "",
    val message: String = "",
    val readFlag: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ComplaintTicket(
    @DocumentId val id: String = "",
    val reporterUid: String = "",
    val reporterRole: String = "TENANT",
    val reporterName: String = "",
    val category: String = "PROPERTY",
    val subject: String = "",
    val description: String = "",
    val status: String = "OPEN",
    val adminResolutionNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class StayReview(
    @DocumentId val id: String = "",
    val bookingId: String = "",
    val reviewerUid: String = "",
    val reviewerRole: String = "TENANT",
    val targetUid: String = "",
    val rating: Long = 5L,
    val comment: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

data class PublicSessionState(
    val uid: String,
    val email: String,
    val displayName: String,
    val profile: UserSecurityProfile,
    val masterUid: String
)
